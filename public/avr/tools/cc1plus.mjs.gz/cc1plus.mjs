// This code implements the `-sMODULARIZE` settings by taking the generated
// JS program code (INNER_JS_CODE) and wrapping it in a factory function.

// When targeting node and ES6 we use `await import ..` in the generated code
// so the outer function needs to be marked as async.
async function Module(moduleArg = {}) {
  var moduleRtn;

// include: shell.js
// include: minimum_runtime_check.js
// end include: minimum_runtime_check.js
// The Module object: Our interface to the outside world. We import
// and export values on it. There are various ways Module can be used:
// 1. Not defined. We create it here
// 2. A function parameter, function(moduleArg) => Promise<Module>
// 3. pre-run appended it, var Module = {}; ..generated code..
// 4. External script tag defines var Module.
// We need to check if Module already exists (e.g. case 3 above).
// Substitution will be replaced with actual code on later stage of the build,
// this way Closure Compiler will not mangle it (e.g. case 4. above).
// Note that if you want to run closure, and also to use Module
// after the generated code, you will need to define   var Module = {};
// before the code. Then that object will be used in the code, and you
// can continue to use Module afterwards as well.
var Module = moduleArg;

// Determine the runtime environment we are in. You can customize this by
// setting the ENVIRONMENT setting at compile time (see settings.js).

// Attempt to auto-detect the environment
var ENVIRONMENT_IS_WEB = !!globalThis.window;
var ENVIRONMENT_IS_WORKER = !!globalThis.WorkerGlobalScope;
// N.b. Electron.js environment is simultaneously a NODE-environment, but
// also a web environment.
var ENVIRONMENT_IS_NODE = globalThis.process?.versions?.node && globalThis.process?.type != 'renderer';
var ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;

// --pre-jses are emitted after the Module integration code, so that they can
// refer to Module (if they choose; they can also define Module)


var arguments_ = [];
var thisProgram = './this.program';
var quit_ = (status, toThrow) => {
  throw toThrow;
};

var _scriptName = import.meta.url;

// `/` should be present at the end if `scriptDirectory` is not empty
var scriptDirectory = '';
function locateFile(path) {
  if (Module['locateFile']) {
    return Module['locateFile'](path, scriptDirectory);
  }
  return scriptDirectory + path;
}

// Hooks that are implemented differently in different runtime environments.
var readAsync, readBinary;

// Note that this includes Node.js workers when relevant (pthreads is enabled).
// Node.js workers are detected as a combination of ENVIRONMENT_IS_WORKER and
// ENVIRONMENT_IS_NODE.
if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
  try {
    scriptDirectory = new URL('.', _scriptName).href; // includes trailing slash
  } catch {
    // Must be a `blob:` or `data:` URL (e.g. `blob:http://site.com/etc/etc`), we cannot
    // infer anything from them.
  }

  {
// include: web_or_worker_shell_read.js
if (ENVIRONMENT_IS_WORKER) {
    readBinary = (url) => {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, false);
      xhr.responseType = 'arraybuffer';
      xhr.send(null);
      return new Uint8Array(/** @type{!ArrayBuffer} */(xhr.response));
    };
  }

  readAsync = async (url) => {
    var response = await fetch(url, { credentials: 'same-origin' });
    if (response.ok) {
      return response.arrayBuffer();
    }
    throw new Error(response.status + ' : ' + response.url);
  };
// end include: web_or_worker_shell_read.js
  }
} else
{
}

var out = console.log.bind(console);
var err = console.error.bind(console);

// end include: shell.js

// include: preamble.js
// === Preamble library stuff ===

// Documentation for the public APIs defined in this file must be updated in:
//    site/source/docs/api_reference/preamble.js.rst
// A prebuilt local version of the documentation is available at:
//    site/build/text/docs/api_reference/preamble.js.txt
// You can also build docs locally as HTML or other formats in site/
// An online HTML version (which may be of a different version of Emscripten)
//    is up at http://kripken.github.io/emscripten-site/docs/api_reference/preamble.js.html

var wasmBinary;

// Wasm globals

//========================================
// Runtime essentials
//========================================

// whether we are quitting the application. no code should run after this.
// set in exit() and abort()
var ABORT = false;

// set by exit() and abort().  Passed to 'onExit' handler.
// NOTE: This is also used as the process return code in shell environments
// but only when noExitRuntime is false.
var EXITSTATUS;

// In STRICT mode, we only define assert() when ASSERTIONS is set.  i.e. we
// don't define it at all in release modes.  This matches the behaviour of
// MINIMAL_RUNTIME.
// TODO(sbc): Make this the default even without STRICT enabled.
/** @type {function(*, string=)} */
function assert(condition, text) {
  if (!condition) {
    // This build was created without ASSERTIONS defined.  `assert()` should not
    // ever be called in this configuration but in case there are callers in
    // the wild leave this simple abort() implementation here for now.
    abort(text);
  }
}

/**
 * Indicates whether filename is delivered via file protocol (as opposed to http/https)
 * @noinline
 */
var isFileURI = (filename) => filename.startsWith('file://');

// include: runtime_common.js
// include: runtime_stack_check.js
// end include: runtime_stack_check.js
// include: runtime_exceptions.js
// Base Emscripten EH error class
class EmscriptenEH {}

class EmscriptenSjLj extends EmscriptenEH {}

// end include: runtime_exceptions.js
// include: runtime_debug.js
// end include: runtime_debug.js
var readyPromiseResolve, readyPromiseReject;

// Memory management

var runtimeInitialized = false;

var runtimeExited = false;



function updateMemoryViews() {
  var b = wasmMemory.buffer;
  HEAP8 = new Int8Array(b);
  HEAP16 = new Int16Array(b);
  HEAPU8 = new Uint8Array(b);
  HEAPU16 = new Uint16Array(b);
  HEAP32 = new Int32Array(b);
  HEAPU32 = new Uint32Array(b);
  HEAPF32 = new Float32Array(b);
  HEAPF64 = new Float64Array(b);
  HEAP64 = new BigInt64Array(b);
  HEAPU64 = new BigUint64Array(b);
}

// include: memoryprofiler.js
// end include: memoryprofiler.js
// end include: runtime_common.js
function preRun() {
  if (Module['preRun']) {
    if (typeof Module['preRun'] == 'function') Module['preRun'] = [Module['preRun']];
    while (Module['preRun'].length) {
      addOnPreRun(Module['preRun'].shift());
    }
  }
  // Begin ATPRERUNS hooks
  callRuntimeCallbacks(onPreRuns);
  // End ATPRERUNS hooks
}

function initRuntime() {
  runtimeInitialized = true;

  // Begin ATINITS hooks
  if (!Module['noFSInit'] && !FS.initialized) FS.init();
TTY.init();
  // End ATINITS hooks

  wasmExports['__wasm_call_ctors']();

  // Begin ATPOSTCTORS hooks
  FS.ignorePermissions = false;
  // End ATPOSTCTORS hooks
}

function preMain() {
  // No ATMAINS hooks
}

function exitRuntime() {
   // PThreads reuse the runtime from the main thread.
  ___funcs_on_exit(); // Native atexit() functions
  // Begin ATEXITS hooks
  FS.quit();
TTY.shutdown();
  // End ATEXITS hooks
  runtimeExited = true;
}

function postRun() {
   // PThreads reuse the runtime from the main thread.

  if (Module['postRun']) {
    if (typeof Module['postRun'] == 'function') Module['postRun'] = [Module['postRun']];
    while (Module['postRun'].length) {
      addOnPostRun(Module['postRun'].shift());
    }
  }

  // Begin ATPOSTRUNS hooks
  callRuntimeCallbacks(onPostRuns);
  // End ATPOSTRUNS hooks
}

/**
 * @param {string|number=} what
 */
function abort(what) {
  Module['onAbort']?.(what);

  what = `Aborted(${what})`;
  // TODO(sbc): Should we remove printing and leave it up to whoever
  // catches the exception?
  err(what);

  ABORT = true;

  what += '. Build with -sASSERTIONS for more info.';

  // Use a wasm runtime error, because a JS error might be seen as a foreign
  // exception, which means we'd run destructors on it. We need the error to
  // simply make the program stop.
  // FIXME This approach does not work in Wasm EH because it currently does not assume
  // all RuntimeErrors are from traps; it decides whether a RuntimeError is from
  // a trap or not based on a hidden field within the object. So at the moment
  // we don't have a way of throwing a wasm trap from JS. TODO Make a JS API that
  // allows this in the wasm spec.

  // Suppress closure compiler warning here. Closure compiler's builtin extern
  // definition for WebAssembly.RuntimeError claims it takes no arguments even
  // though it can.
  // TODO(https://github.com/google/closure-compiler/pull/3913): Remove if/when upstream closure gets fixed.
  /** @suppress {checkTypes} */
  var e = new WebAssembly.RuntimeError(what);

  readyPromiseReject?.(e);
  // Throw the error whether or not MODULARIZE is set because abort is used
  // in code paths apart from instantiation where an exception is expected
  // to be thrown when abort is called.
  throw e;
}

var wasmBinaryFile;

function findWasmBinary() {

  if (Module['locateFile']) {
    return locateFile('cc1plus.wasm');
  }

  // Use bundler-friendly `new URL(..., import.meta.url)` pattern; works in browsers too.
  return new URL('cc1plus.wasm', import.meta.url).href;

}

function getBinarySync(file) {
  if (file == wasmBinaryFile && wasmBinary) {
    return new Uint8Array(wasmBinary);
  }
  if (readBinary) {
    return readBinary(file);
  }
  // Throwing a plain string here, even though it not normally advisable since
  // this gets turning into an `abort` in instantiateArrayBuffer.
  throw 'both async and sync fetching of the wasm failed';
}

async function getWasmBinary(binaryFile) {
  // If we don't have the binary yet, load it asynchronously using readAsync.
  if (!wasmBinary) {
    // Fetch the binary using readAsync
    try {
      var response = await readAsync(binaryFile);
      return new Uint8Array(response);
    } catch {
      // Fall back to getBinarySync below;
    }
  }

  // Otherwise, getBinarySync should be able to get it synchronously
  return getBinarySync(binaryFile);
}

async function instantiateArrayBuffer(binaryFile, imports) {
  try {
    var binary = await getWasmBinary(binaryFile);
    var instance = await WebAssembly.instantiate(binary, imports);
    return instance;
  } catch (reason) {
    err(`failed to asynchronously prepare wasm: ${reason}`);

    abort(reason);
  }
}

async function instantiateAsync(binary, binaryFile, imports) {
  if (!binary
     ) {
    try {
      var response = fetch(binaryFile, { credentials: 'same-origin' });
      var instantiationResult = await WebAssembly.instantiateStreaming(response, imports);
      return instantiationResult;
    } catch (reason) {
      // We expect the most common failure cause to be a bad MIME type for the binary,
      // in which case falling back to ArrayBuffer instantiation should work.
      err(`wasm streaming compile failed: ${reason}`);
      err('falling back to ArrayBuffer instantiation');
      // fall back of instantiateArrayBuffer below
    };
  }
  return instantiateArrayBuffer(binaryFile, imports);
}

function getWasmImports() {
  // prepare imports
  var imports = {
    'env': wasmImports,
    'wasi_snapshot_preview1': wasmImports,
  };
  return imports;
}

// Create the wasm instance.
// Receives the wasm imports, returns the exports.
async function createWasm() {
  // Load the wasm module and create an instance of using native support in the JS engine.
  // handle a generated wasm instance, receiving its exports and
  // performing other necessary setup
  /** @param {WebAssembly.Module=} module*/
  function receiveInstance(instance, module) {
    wasmExports = instance.exports;

    assignWasmExports(wasmExports);

    updateMemoryViews();

    return wasmExports;
  }

  // Prefer streaming instantiation if available.
  function receiveInstantiationResult(result) {
    // 'result' is a ResultObject object which has both the module and instance.
    // receiveInstance() will swap in the exports (to Module.asm) so they can be called
    // TODO: Due to Closure regression https://github.com/google/closure-compiler/issues/3193, the above line no longer optimizes out down to the following line.
    // When the regression is fixed, can restore the above PTHREADS-enabled path.
    return receiveInstance(result['instance']);
  }

  var info = getWasmImports();

  // User shell pages can write their own Module.instantiateWasm = function(imports, successCallback) callback
  // to manually instantiate the Wasm module themselves. This allows pages to
  // run the instantiation parallel to any other async startup actions they are
  // performing.
  // Also pthreads and wasm workers initialize the wasm instance through this
  // path.
  if (Module['instantiateWasm']) {
    return new Promise((resolve, reject) => {
        Module['instantiateWasm'](info, (inst, mod) => {
          resolve(receiveInstance(inst, mod));
        });
    });
  }

  wasmBinaryFile ??= findWasmBinary();
  var result = await instantiateAsync(wasmBinary, wasmBinaryFile, info);
  var exports = receiveInstantiationResult(result);
  return exports;
}

// end include: preamble.js

// Begin JS library code


  class ExitStatus {
      name = 'ExitStatus';
      constructor(status) {
        this.message = `Program terminated with exit(${status})`;
        this.status = status;
      }
    }

  /** @type {!Int16Array} */
  var HEAP16;

  /** @type {!Int32Array} */
  var HEAP32;

  /** not-@type {!BigInt64Array} */
  var HEAP64;

  /** @type {!Int8Array} */
  var HEAP8;

  /** @type {!Float32Array} */
  var HEAPF32;

  /** @type {!Float64Array} */
  var HEAPF64;

  /** @type {!Uint16Array} */
  var HEAPU16;

  /** @type {!Uint32Array} */
  var HEAPU32;

  /** not-@type {!BigUint64Array} */
  var HEAPU64;

  /** @type {!Uint8Array} */
  var HEAPU8;

  var callRuntimeCallbacks = (callbacks) => {
      while (callbacks.length > 0) {
        // Pass the module as the first argument.
        callbacks.shift()(Module);
      }
    };
  var onPostRuns = [];
  var addOnPostRun = (cb) => onPostRuns.push(cb);

  var onPreRuns = [];
  var addOnPreRun = (cb) => onPreRuns.push(cb);


  
    /**
   * @param {number} ptr
   * @param {string} type
   */
  function getValue(ptr, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1': return HEAP8[ptr];
      case 'i8': return HEAP8[ptr];
      case 'i16': return HEAP16[((ptr)>>1)];
      case 'i32': return HEAP32[((ptr)>>2)];
      case 'i64': return HEAP64[((ptr)>>3)];
      case 'float': return HEAPF32[((ptr)>>2)];
      case 'double': return HEAPF64[((ptr)>>3)];
      case '*': return HEAPU32[((ptr)>>2)];
      default: abort(`invalid type for getValue: ${type}`);
    }
  }

  var noExitRuntime = false;

  
    /**
   * @param {number} ptr
   * @param {number} value
   * @param {string} type
   */
  function setValue(ptr, value, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1': HEAP8[ptr] = value; break;
      case 'i8': HEAP8[ptr] = value; break;
      case 'i16': HEAP16[((ptr)>>1)] = value; break;
      case 'i32': HEAP32[((ptr)>>2)] = value; break;
      case 'i64': HEAP64[((ptr)>>3)] = BigInt(value); break;
      case 'float': HEAPF32[((ptr)>>2)] = value; break;
      case 'double': HEAPF64[((ptr)>>3)] = value; break;
      case '*': HEAPU32[((ptr)>>2)] = value; break;
      default: abort(`invalid type for setValue: ${type}`);
    }
  }

  var stackRestore = (val) => __emscripten_stack_restore(val);

  var stackSave = () => _emscripten_stack_get_current();

  

  var jsStackTrace = () => new Error().stack.toString();
  /** @param {number=} flags */
  var getCallstack = (flags) => {
      var callstack = jsStackTrace();
  
      // Process all lines:
      var lines = callstack.split('\n');
      callstack = '';
      // Extract components of form:
      // '       Object._main@http://server.com:4324:12'
      var firefoxRe = new RegExp('\\s*(.*?)@(.*?):([0-9]+):([0-9]+)');
      // Extract components of form:
      // '    at Object._main (http://server.com/file.html:4324:12)'
      var chromeRe = new RegExp('\\s*at (.*?) \\\((.*):(.*):(.*)\\\)');
  
      for (var line of lines) {
        var symbolName = '';
        var file = '';
        var lineno = 0;
        var column = 0;
  
        var parts = chromeRe.exec(line);
        if (parts?.length == 5) {
          symbolName = parts[1];
          file = parts[2];
          lineno = parts[3];
          column = parts[4];
        } else {
          parts = firefoxRe.exec(line);
          if (parts?.length >= 4) {
            symbolName = parts[1];
            file = parts[2];
            lineno = parts[3];
            // Old Firefox doesn't carry column information, but in new FF30, it
            // is present. See https://bugzil.la/762556
            column = parts[4]|0;
          } else {
            // Was not able to extract this line for demangling/sourcemapping
            // purposes. Output it as-is.
            callstack += line + '\n';
            continue;
          }
        }
  
        // Find the symbols in the callstack that corresponds to the functions that
        // report callstack information, and remove everything up to these from the
        // output.
        if (symbolName == '_emscripten_log' || symbolName == '_emscripten_get_callstack') {
          callstack = '';
          continue;
        }
  
        if ((flags & 24)) {
          if (flags & 64) {
            file = file.substring(file.replace(/\\/g, "/").lastIndexOf('/')+1);
          }
          callstack += `    at ${symbolName} (${file}:${lineno}:${column})\n`;
        }
      }
      // Trim extra whitespace at the end of the output.
      callstack = callstack.replace(/\s+$/, '');
      return callstack;
    };
  
  var wasmTableMirror = [];
  
  
  var getWasmTableEntry = (funcPtr) => {
      var func = wasmTableMirror[funcPtr];
      if (!func) {
        /** @suppress {checkTypes} */
        wasmTableMirror[funcPtr] = func = wasmTable.get(funcPtr);
      }
      return func;
    };
  var __Unwind_Backtrace = (func, arg) => {
      var trace = getCallstack();
      var parts = trace.split('\n');
      for (var i = 0; i < parts.length; i++) {
        var ret = getWasmTableEntry(func)(0, arg);
        if (ret !== 0) return;
      }
    };

  var __Unwind_GetIPInfo = (context, ipBefore) => abort('Unwind_GetIPInfo');

  var ___call_sighandler = (fp, sig) => getWasmTableEntry(fp)(sig);

  var PATH = {
  isAbs:(path) => path.charAt(0) === '/',
  splitPath:(filename) => {
        var splitPathRe = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
        return splitPathRe.exec(filename).slice(1);
      },
  normalizeArray:(parts, allowAboveRoot) => {
        // if the path tries to go above the root, `up` ends up > 0
        var up = 0;
        for (var i = parts.length - 1; i >= 0; i--) {
          var last = parts[i];
          if (last === '.') {
            parts.splice(i, 1);
          } else if (last === '..') {
            parts.splice(i, 1);
            up++;
          } else if (up) {
            parts.splice(i, 1);
            up--;
          }
        }
        // if the path is allowed to go above the root, restore leading ..s
        if (allowAboveRoot) {
          for (; up; up--) {
            parts.unshift('..');
          }
        }
        return parts;
      },
  normalize:(path) => {
        var isAbsolute = PATH.isAbs(path),
            trailingSlash = path.slice(-1) === '/';
        // Normalize the path
        path = PATH.normalizeArray(path.split('/').filter((p) => !!p), !isAbsolute).join('/');
        if (!path && !isAbsolute) {
          path = '.';
        }
        if (path && trailingSlash) {
          path += '/';
        }
        return (isAbsolute ? '/' : '') + path;
      },
  dirname:(path) => {
        var result = PATH.splitPath(path),
            root = result[0],
            dir = result[1];
        if (!root && !dir) {
          // No dirname whatsoever
          return '.';
        }
        if (dir) {
          // It has a dirname, strip trailing slash
          dir = dir.slice(0, -1);
        }
        return root + dir;
      },
  basename:(path) => path && path.match(/([^\/]+|\/)\/*$/)[1],
join:(...paths) => PATH.normalize(paths.join('/')),
join2:(l, r) => PATH.normalize(l + '/' + r),
};

var initRandomFill = () => {

    return (view) => (crypto.getRandomValues(view), 0);
  };
var randomFill = (view) => (randomFill = initRandomFill())(view);



var PATH_FS = {
resolve:(...args) => {
      var resolvedPath = '',
        resolvedAbsolute = false;
      for (var i = args.length - 1; i >= -1 && !resolvedAbsolute; i--) {
        var path = (i >= 0) ? args[i] : FS.cwd();
        // Skip empty and invalid entries
        if (typeof path != 'string') {
          throw new TypeError('Arguments to path.resolve must be strings');
        } else if (!path) {
          return ''; // an invalid portion invalidates the whole thing
        }
        resolvedPath = path + '/' + resolvedPath;
        resolvedAbsolute = PATH.isAbs(path);
      }
      // At this point the path should be resolved to a full absolute path, but
      // handle relative paths to be safe (might happen when process.cwd() fails)
      resolvedPath = PATH.normalizeArray(resolvedPath.split('/').filter((p) => !!p), !resolvedAbsolute).join('/');
      return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
    },
relative:(from, to) => {
      from = PATH_FS.resolve(from).slice(1);
      to = PATH_FS.resolve(to).slice(1);
      function trim(arr) {
        var start = 0;
        for (; start < arr.length; start++) {
          if (arr[start] !== '') break;
        }
        var end = arr.length - 1;
        for (; end >= 0; end--) {
          if (arr[end] !== '') break;
        }
        if (start > end) return [];
        return arr.slice(start, end - start + 1);
      }
      var fromParts = trim(from.split('/'));
      var toParts = trim(to.split('/'));
      var length = Math.min(fromParts.length, toParts.length);
      var samePartsLength = length;
      for (var i = 0; i < length; i++) {
        if (fromParts[i] !== toParts[i]) {
          samePartsLength = i;
          break;
        }
      }
      var outputParts = [];
      for (var i = samePartsLength; i < fromParts.length; i++) {
        outputParts.push('..');
      }
      outputParts = outputParts.concat(toParts.slice(samePartsLength));
      return outputParts.join('/');
    },
};


var UTF8Decoder = globalThis.TextDecoder && new TextDecoder();

var findStringEnd = (heapOrArray, idx, maxBytesToRead, ignoreNul) => {
    var maxIdx = idx + maxBytesToRead;
    if (ignoreNul) return maxIdx;
    // TextDecoder needs to know the byte length in advance, it doesn't stop on
    // null terminator by itself.
    // As a tiny code save trick, compare idx against maxIdx using a negation,
    // so that maxBytesToRead=undefined/NaN means Infinity.
    while (heapOrArray[idx] && !(idx >= maxIdx)) ++idx;
    return idx;
  };

  /**
   * Given a pointer 'idx' to a null-terminated UTF8-encoded string in the given
   * array that contains uint8 values, returns a copy of that string as a
   * Javascript String object.
   * heapOrArray is either a regular array, or a JavaScript typed array view.
   * @param {number=} idx
   * @param {number=} maxBytesToRead
   * @param {boolean=} ignoreNul - If true, the function will not stop on a NUL character.
   * @return {string}
   */
  var UTF8ArrayToString = (heapOrArray, idx = 0, maxBytesToRead, ignoreNul) => {
  
      var endPtr = findStringEnd(heapOrArray, idx, maxBytesToRead, ignoreNul);
  
      // When using conditional TextDecoder, skip it for short strings as the overhead of the native call is not worth it.
      if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
        return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
      }
      var str = '';
      while (idx < endPtr) {
        // For UTF8 byte structure, see:
        // http://en.wikipedia.org/wiki/UTF-8#Description
        // https://www.ietf.org/rfc/rfc2279.txt
        // https://tools.ietf.org/html/rfc3629
        var u0 = heapOrArray[idx++];
        if (!(u0 & 0x80)) { str += String.fromCharCode(u0); continue; }
        var u1 = heapOrArray[idx++] & 63;
        if ((u0 & 0xE0) == 0xC0) { str += String.fromCharCode(((u0 & 31) << 6) | u1); continue; }
        var u2 = heapOrArray[idx++] & 63;
        if ((u0 & 0xF0) == 0xE0) {
          u0 = ((u0 & 15) << 12) | (u1 << 6) | u2;
        } else {
          u0 = ((u0 & 7) << 18) | (u1 << 12) | (u2 << 6) | (heapOrArray[idx++] & 63);
        }
  
        if (u0 < 0x10000) {
          str += String.fromCharCode(u0);
        } else {
          var ch = u0 - 0x10000;
          str += String.fromCharCode(0xD800 | (ch >> 10), 0xDC00 | (ch & 0x3FF));
        }
      }
      return str;
    };
  
  var FS_stdin_getChar_buffer = [];
  
  var lengthBytesUTF8 = (str) => {
      var len = 0;
      for (var i = 0; i < str.length; ++i) {
        // Gotcha: charCodeAt returns a 16-bit word that is a UTF-16 encoded code
        // unit, not a Unicode code point of the character! So decode
        // UTF16->UTF32->UTF8.
        // See http://unicode.org/faq/utf_bom.html#utf16-3
        var c = str.charCodeAt(i); // possibly a lead surrogate
        if (c <= 0x7F) {
          len++;
        } else if (c <= 0x7FF) {
          len += 2;
        } else if (c >= 0xD800 && c <= 0xDFFF) {
          len += 4; ++i;
        } else {
          len += 3;
        }
      }
      return len;
    };
  
  var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
      // Parameter maxBytesToWrite is not optional. Negative values, 0, null,
      // undefined and false each don't write out any bytes.
      if (!(maxBytesToWrite > 0))
        return 0;
  
      var startIdx = outIdx;
      var endIdx = outIdx + maxBytesToWrite - 1; // -1 for string null terminator.
      for (var i = 0; i < str.length; ++i) {
        // For UTF8 byte structure, see http://en.wikipedia.org/wiki/UTF-8#Description
        // and https://www.ietf.org/rfc/rfc2279.txt
        // and https://tools.ietf.org/html/rfc3629
        var u = str.codePointAt(i);
        if (u <= 0x7F) {
          if (outIdx >= endIdx) break;
          heap[outIdx++] = u;
        } else if (u <= 0x7FF) {
          if (outIdx + 1 >= endIdx) break;
          heap[outIdx++] = 0xC0 | (u >> 6);
          heap[outIdx++] = 0x80 | (u & 63);
        } else if (u <= 0xFFFF) {
          if (outIdx + 2 >= endIdx) break;
          heap[outIdx++] = 0xE0 | (u >> 12);
          heap[outIdx++] = 0x80 | ((u >> 6) & 63);
          heap[outIdx++] = 0x80 | (u & 63);
        } else {
          if (outIdx + 3 >= endIdx) break;
          heap[outIdx++] = 0xF0 | (u >> 18);
          heap[outIdx++] = 0x80 | ((u >> 12) & 63);
          heap[outIdx++] = 0x80 | ((u >> 6) & 63);
          heap[outIdx++] = 0x80 | (u & 63);
          // Gotcha: if codePoint is over 0xFFFF, it is represented as a surrogate pair in UTF-16.
          // We need to manually skip over the second code unit for correct iteration.
          i++;
        }
      }
      // Null-terminate the pointer to the buffer.
      heap[outIdx] = 0;
      return outIdx - startIdx;
    };
  /** @type {function(string, boolean=, number=)} */
  var intArrayFromString = (stringy, dontAddNull, length) => {
      var len = length > 0 ? length : lengthBytesUTF8(stringy)+1;
      var u8array = new Array(len);
      var numBytesWritten = stringToUTF8Array(stringy, u8array, 0, u8array.length);
      if (dontAddNull) u8array.length = numBytesWritten;
      return u8array;
    };
  var FS_stdin_getChar = () => {
      if (!FS_stdin_getChar_buffer.length) {
        var result = null;
        if (globalThis.window?.prompt) {
          // Browser.
          result = window.prompt('Input: ');  // returns null on cancel
          if (result !== null) {
            result += '\n';
          }
        } else
        {}
        if (!result) {
          return null;
        }
        FS_stdin_getChar_buffer = intArrayFromString(result, true);
      }
      return FS_stdin_getChar_buffer.shift();
    };
  var TTY = {
  ttys:[],
  init() {
        // https://github.com/emscripten-core/emscripten/pull/1555
        // if (ENVIRONMENT_IS_NODE) {
        //   // currently, FS.init does not distinguish if process.stdin is a file or TTY
        //   // device, it always assumes it's a TTY device. because of this, we're forcing
        //   // process.stdin to UTF8 encoding to at least make stdin reading compatible
        //   // with text files until FS.init can be refactored.
        //   process.stdin.setEncoding('utf8');
        // }
      },
  shutdown() {
        // https://github.com/emscripten-core/emscripten/pull/1555
        // if (ENVIRONMENT_IS_NODE) {
        //   // inolen: any idea as to why node -e 'process.stdin.read()' wouldn't exit immediately (with process.stdin being a tty)?
        //   // isaacs: because now it's reading from the stream, you've expressed interest in it, so that read() kicks off a _read() which creates a ReadReq operation
        //   // inolen: I thought read() in that case was a synchronous operation that just grabbed some amount of buffered data if it exists?
        //   // isaacs: it is. but it also triggers a _read() call, which calls readStart() on the handle
        //   // isaacs: do process.stdin.pause() and i'd think it'd probably close the pending call
        //   process.stdin.pause();
        // }
      },
  register(dev, ops) {
        TTY.ttys[dev] = { input: [], output: [], ops: ops };
        FS.registerDevice(dev, TTY.stream_ops);
      },
  stream_ops:{
  open(stream) {
          var tty = TTY.ttys[stream.node.rdev];
          if (!tty) {
            throw new FS.ErrnoError(43);
          }
          stream.tty = tty;
          stream.seekable = false;
        },
  close(stream) {
          // flush any pending line data
          stream.tty.ops.fsync(stream.tty);
        },
  fsync(stream) {
          stream.tty.ops.fsync(stream.tty);
        },
  read(stream, buffer, offset, length, pos /* ignored */) {
          if (!stream.tty || !stream.tty.ops.get_char) {
            throw new FS.ErrnoError(60);
          }
          var bytesRead = 0;
          for (var i = 0; i < length; i++) {
            var result;
            try {
              result = stream.tty.ops.get_char(stream.tty);
            } catch (e) {
              throw new FS.ErrnoError(29);
            }
            if (result === undefined && bytesRead === 0) {
              throw new FS.ErrnoError(6);
            }
            if (result === null || result === undefined) break;
            bytesRead++;
            buffer[offset+i] = result;
          }
          if (bytesRead) {
            stream.node.atime = Date.now();
          }
          return bytesRead;
        },
  write(stream, buffer, offset, length, pos) {
          if (!stream.tty || !stream.tty.ops.put_char) {
            throw new FS.ErrnoError(60);
          }
          try {
            for (var i = 0; i < length; i++) {
              stream.tty.ops.put_char(stream.tty, buffer[offset+i]);
            }
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
          if (length) {
            stream.node.mtime = stream.node.ctime = Date.now();
          }
          return i;
        },
  },
  default_tty_ops:{
  get_char(tty) {
          return FS_stdin_getChar();
        },
  put_char(tty, val) {
          if (val === null || val === 10) {
            out(UTF8ArrayToString(tty.output));
            tty.output = [];
          } else {
            if (val != 0) tty.output.push(val); // val == 0 would cut text output off in the middle.
          }
        },
  fsync(tty) {
          if (tty.output?.length > 0) {
            out(UTF8ArrayToString(tty.output));
            tty.output = [];
          }
        },
  ioctl_tcgets(tty) {
          // typical setting
          return {
            c_iflag: 25856,
            c_oflag: 5,
            c_cflag: 191,
            c_lflag: 35387,
            c_cc: [
              0x03, 0x1c, 0x7f, 0x15, 0x04, 0x00, 0x01, 0x00, 0x11, 0x13, 0x1a, 0x00,
              0x12, 0x0f, 0x17, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]
          };
        },
  ioctl_tcsets(tty, optional_actions, data) {
          // currently just ignore
          return 0;
        },
  ioctl_tiocgwinsz(tty) {
          return [24, 80];
        },
  },
  default_tty1_ops:{
  put_char(tty, val) {
          if (val === null || val === 10) {
            err(UTF8ArrayToString(tty.output));
            tty.output = [];
          } else {
            if (val != 0) tty.output.push(val);
          }
        },
  fsync(tty) {
          if (tty.output?.length > 0) {
            err(UTF8ArrayToString(tty.output));
            tty.output = [];
          }
        },
  },
  };
  
  
  var zeroMemory = (ptr, size) => HEAPU8.fill(0, ptr, ptr + size);
  
  var alignMemory = (size, alignment) => {
      return Math.ceil(size / alignment) * alignment;
    };
  var mmapAlloc = (size) => {
      size = alignMemory(size, 65536);
      var ptr = _emscripten_builtin_memalign(65536, size);
      if (ptr) zeroMemory(ptr, size);
      return ptr;
    };
  var MEMFS = {
  ops_table:null,
  mount(mount) {
        return MEMFS.createNode(null, '/', 16895, 0);
      },
  createNode(parent, name, mode, dev) {
        if (FS.isBlkdev(mode) || FS.isFIFO(mode)) {
          // not supported
          throw new FS.ErrnoError(63);
        }
        MEMFS.ops_table ||= {
          dir: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr,
              lookup: MEMFS.node_ops.lookup,
              mknod: MEMFS.node_ops.mknod,
              rename: MEMFS.node_ops.rename,
              unlink: MEMFS.node_ops.unlink,
              rmdir: MEMFS.node_ops.rmdir,
              readdir: MEMFS.node_ops.readdir,
              symlink: MEMFS.node_ops.symlink
            },
            stream: {
              llseek: MEMFS.stream_ops.llseek
            }
          },
          file: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr
            },
            stream: {
              llseek: MEMFS.stream_ops.llseek,
              read: MEMFS.stream_ops.read,
              write: MEMFS.stream_ops.write,
              mmap: MEMFS.stream_ops.mmap,
              msync: MEMFS.stream_ops.msync
            }
          },
          link: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr,
              readlink: MEMFS.node_ops.readlink
            },
            stream: {}
          },
          chrdev: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr
            },
            stream: FS.chrdev_stream_ops
          }
        };
        var node = FS.createNode(parent, name, mode, dev);
        if (FS.isDir(node.mode)) {
          node.node_ops = MEMFS.ops_table.dir.node;
          node.stream_ops = MEMFS.ops_table.dir.stream;
          node.contents = {};
        } else if (FS.isFile(node.mode)) {
          node.node_ops = MEMFS.ops_table.file.node;
          node.stream_ops = MEMFS.ops_table.file.stream;
          // The actual number of bytes used in the typed array, as opposed to
          // contents.length which gives the whole capacity.
          node.usedBytes = 0;
          // The byte data of the file is stored in a typed array.
          // Note: typed arrays are not resizable like normal JS arrays are, so
          // there is a small penalty involved for appending file writes that
          // continuously grow a file similar to std::vector capacity vs used.
          node.contents = MEMFS.emptyFileContents ??= new Uint8Array(0);
        } else if (FS.isLink(node.mode)) {
          node.node_ops = MEMFS.ops_table.link.node;
          node.stream_ops = MEMFS.ops_table.link.stream;
        } else if (FS.isChrdev(node.mode)) {
          node.node_ops = MEMFS.ops_table.chrdev.node;
          node.stream_ops = MEMFS.ops_table.chrdev.stream;
        }
        node.atime = node.mtime = node.ctime = Date.now();
        // add the new node to the parent
        if (parent) {
          parent.contents[name] = node;
          parent.atime = parent.mtime = parent.ctime = node.atime;
        }
        return node;
      },
  getFileDataAsTypedArray(node) {
        return node.contents.subarray(0, node.usedBytes); // Make sure to not return excess unused bytes.
      },
  expandFileStorage(node, newCapacity) {
        var prevCapacity = node.contents.length;
        if (prevCapacity >= newCapacity) return; // No need to expand, the storage was already large enough.
        // Don't expand strictly to the given requested limit if it's only a very
        // small increase, but instead geometrically grow capacity.
        // For small filesizes (<1MB), perform size*2 geometric increase, but for
        // large sizes, do a much more conservative size*1.125 increase to avoid
        // overshooting the allocation cap by a very large margin.
        var CAPACITY_DOUBLING_MAX = 1024 * 1024;
        newCapacity = Math.max(newCapacity, (prevCapacity * (prevCapacity < CAPACITY_DOUBLING_MAX ? 2.0 : 1.125)) >>> 0);
        if (prevCapacity) newCapacity = Math.max(newCapacity, 256); // At minimum allocate 256b for each file when expanding.
        var oldContents = MEMFS.getFileDataAsTypedArray(node);
        node.contents = new Uint8Array(newCapacity); // Allocate new storage.
        node.contents.set(oldContents);
      },
  resizeFileStorage(node, newSize) {
        if (node.usedBytes == newSize) return;
        var oldContents = node.contents;
        node.contents = new Uint8Array(newSize); // Allocate new storage.
        node.contents.set(oldContents.subarray(0, Math.min(newSize, node.usedBytes))); // Copy old data over to the new storage.
        node.usedBytes = newSize;
      },
  node_ops:{
  getattr(node) {
          var attr = {};
          // device numbers reuse inode numbers.
          attr.dev = FS.isChrdev(node.mode) ? node.id : 1;
          attr.ino = node.id;
          attr.mode = node.mode;
          attr.nlink = 1;
          attr.uid = 0;
          attr.gid = 0;
          attr.rdev = node.rdev;
          if (FS.isDir(node.mode)) {
            attr.size = 4096;
          } else if (FS.isFile(node.mode)) {
            attr.size = node.usedBytes;
          } else if (FS.isLink(node.mode)) {
            attr.size = node.link.length;
          } else {
            attr.size = 0;
          }
          attr.atime = new Date(node.atime);
          attr.mtime = new Date(node.mtime);
          attr.ctime = new Date(node.ctime);
          // NOTE: In our implementation, st_blocks = Math.ceil(st_size/st_blksize),
          //       but this is not required by the standard.
          attr.blksize = 4096;
          attr.blocks = Math.ceil(attr.size / attr.blksize);
          return attr;
        },
  setattr(node, attr) {
          for (const key of ["mode", "atime", "mtime", "ctime"]) {
            if (attr[key] != null) {
              node[key] = attr[key];
            }
          }
          if (attr.size !== undefined) {
            MEMFS.resizeFileStorage(node, attr.size);
          }
        },
  lookup(parent, name) {
          // This error may happen quite a bit. To avoid overhead we reuse it (and
          // suffer a lack of stack info).
          if (!MEMFS.doesNotExistError) {
            MEMFS.doesNotExistError = new FS.ErrnoError(44);
            /** @suppress {checkTypes} */
            MEMFS.doesNotExistError.stack = '<generic error, no stack>';
          }
          throw MEMFS.doesNotExistError;
        },
  mknod(parent, name, mode, dev) {
          return MEMFS.createNode(parent, name, mode, dev);
        },
  rename(old_node, new_dir, new_name) {
          var new_node;
          try {
            new_node = FS.lookupNode(new_dir, new_name);
          } catch (e) {}
          if (new_node) {
            if (FS.isDir(old_node.mode)) {
              // if we're overwriting a directory at new_name, make sure it's empty.
              for (var i in new_node.contents) {
                throw new FS.ErrnoError(55);
              }
            }
            FS.hashRemoveNode(new_node);
          }
          // do the internal rewiring
          delete old_node.parent.contents[old_node.name];
          new_dir.contents[new_name] = old_node;
          old_node.name = new_name;
          new_dir.ctime = new_dir.mtime = old_node.parent.ctime = old_node.parent.mtime = Date.now();
        },
  unlink(parent, name) {
          delete parent.contents[name];
          parent.ctime = parent.mtime = Date.now();
        },
  rmdir(parent, name) {
          var node = FS.lookupNode(parent, name);
          for (var i in node.contents) {
            throw new FS.ErrnoError(55);
          }
          delete parent.contents[name];
          parent.ctime = parent.mtime = Date.now();
        },
  readdir(node) {
          return ['.', '..', ...Object.keys(node.contents)];
        },
  symlink(parent, newname, oldpath) {
          var node = MEMFS.createNode(parent, newname, 0o777 | 40960, 0);
          node.link = oldpath;
          return node;
        },
  readlink(node) {
          if (!FS.isLink(node.mode)) {
            throw new FS.ErrnoError(28);
          }
          return node.link;
        },
  },
  stream_ops:{
  read(stream, buffer, offset, length, position) {
          var contents = stream.node.contents;
          if (position >= stream.node.usedBytes) return 0;
          var size = Math.min(stream.node.usedBytes - position, length);
          buffer.set(contents.subarray(position, position + size), offset);
          return size;
        },
  write(stream, buffer, offset, length, position, canOwn) {
          // If the buffer is located in main memory (HEAP), and if
          // memory can grow, we can't hold on to references of the
          // memory buffer, as they may get invalidated. That means we
          // need to copy its contents.
          if (buffer.buffer === HEAP8.buffer) {
            canOwn = false;
          }
  
          if (!length) return 0;
          var node = stream.node;
          node.mtime = node.ctime = Date.now();
  
          if (canOwn) {
            node.contents = buffer.subarray(offset, offset + length);
            node.usedBytes = length;
          } else if (node.usedBytes === 0 && position === 0) { // If this is a simple first write to an empty file, do a fast set since we don't need to care about old data.
            node.contents = buffer.slice(offset, offset + length);
            node.usedBytes = length;
          } else {
            MEMFS.expandFileStorage(node, position+length);
            // Use typed array write which is available.
            node.contents.set(buffer.subarray(offset, offset + length), position);
            node.usedBytes = Math.max(node.usedBytes, position + length);
          }
          return length;
        },
  llseek(stream, offset, whence) {
          var position = offset;
          if (whence === 1) {
            position += stream.position;
          } else if (whence === 2) {
            if (FS.isFile(stream.node.mode)) {
              position += stream.node.usedBytes;
            }
          }
          if (position < 0) {
            throw new FS.ErrnoError(28);
          }
          return position;
        },
  mmap(stream, length, position, prot, flags) {
          if (!FS.isFile(stream.node.mode)) {
            throw new FS.ErrnoError(43);
          }
          var ptr;
          var allocated;
          var contents = stream.node.contents;
          // Only make a new copy when MAP_PRIVATE is specified.
          if (!(flags & 2) && contents.buffer === HEAP8.buffer) {
            // We can't emulate MAP_SHARED when the file is not backed by the
            // buffer we're mapping to (e.g. the HEAP buffer).
            allocated = false;
            ptr = contents.byteOffset;
          } else {
            allocated = true;
            ptr = mmapAlloc(length);
            if (!ptr) {
              throw new FS.ErrnoError(48);
            }
            if (contents) {
              // Try to avoid unnecessary slices.
              if (position > 0 || position + length < contents.length) {
                if (contents.subarray) {
                  contents = contents.subarray(position, position + length);
                } else {
                  contents = Array.prototype.slice.call(contents, position, position + length);
                }
              }
              HEAP8.set(contents, ptr);
            }
          }
          return { ptr, allocated };
        },
  msync(stream, buffer, offset, length, mmapFlags) {
          MEMFS.stream_ops.write(stream, buffer, 0, length, offset, false);
          // should we check if bytesWritten and length are the same?
          return 0;
        },
  },
  };
  
  var FS_modeStringToFlags = (str) => {
      if (typeof str != 'string') return str;
      var flagModes = {
        'r': 0,
        'r+': 2,
        'w': 512 | 64 | 1,
        'w+': 512 | 64 | 2,
        'a': 1024 | 64 | 1,
        'a+': 1024 | 64 | 2,
      };
      var flags = flagModes[str];
      if (typeof flags == 'undefined') {
        throw new Error(`Unknown file open mode: ${str}`);
      }
      return flags;
    };
  
  var FS_fileDataToTypedArray = (data) => {
      if (typeof data == 'string') {
        data = intArrayFromString(data, true);
      }
      if (!data.subarray) {
        data = new Uint8Array(data);
      }
      return data;
    };
  
  var FS_getMode = (canRead, canWrite) => {
      var mode = 0;
      if (canRead) mode |= 292 | 73;
      if (canWrite) mode |= 146;
      return mode;
    };
  
  
  var asyncLoad = async (url) => {
      var arrayBuffer = await readAsync(url);
      return new Uint8Array(arrayBuffer);
    };
  
  
  var FS_createDataFile = (...args) => FS.createDataFile(...args);
  
  var getUniqueRunDependency = (id) => {
      return id;
    };
  
  var runDependencies = 0;
  
  
  var dependenciesFulfilled = null;
  var removeRunDependency = (id) => {
      runDependencies--;
  
      Module['monitorRunDependencies']?.(runDependencies);
  
      if (runDependencies == 0) {
        if (dependenciesFulfilled) {
          var callback = dependenciesFulfilled;
          dependenciesFulfilled = null;
          callback(); // can add another dependenciesFulfilled
        }
      }
    };
  var addRunDependency = (id) => {
      runDependencies++;
  
      Module['monitorRunDependencies']?.(runDependencies);
  
    };
  
  
  var preloadPlugins = [];
  var FS_handledByPreloadPlugin = async (byteArray, fullname) => {
      // Ensure plugins are ready.
      if (typeof Browser != 'undefined') Browser.init();
  
      for (var plugin of preloadPlugins) {
        if (plugin['canHandle'](fullname)) {
          return plugin['handle'](byteArray, fullname);
        }
      }
      // If no plugin handled this file then return the original/unmodified
      // byteArray.
      return byteArray;
    };
  var FS_preloadFile = async (parent, name, url, canRead, canWrite, dontCreateFile, canOwn, preFinish) => {
      // TODO we should allow people to just pass in a complete filename instead
      // of parent and name being that we just join them anyways
      var fullname = name ? PATH_FS.resolve(PATH.join2(parent, name)) : parent;
      var dep = getUniqueRunDependency(`cp ${fullname}`); // might have several active requests for the same fullname
      addRunDependency(dep);
  
      try {
        var byteArray = url;
        if (typeof url == 'string') {
          byteArray = await asyncLoad(url);
        }
  
        byteArray = await FS_handledByPreloadPlugin(byteArray, fullname);
        preFinish?.();
        if (!dontCreateFile) {
          FS_createDataFile(parent, name, byteArray, canRead, canWrite, canOwn);
        }
      } finally {
        removeRunDependency(dep);
      }
    };
  var FS_createPreloadedFile = (parent, name, url, canRead, canWrite, onload, onerror, dontCreateFile, canOwn, preFinish) => {
      FS_preloadFile(parent, name, url, canRead, canWrite, dontCreateFile, canOwn, preFinish).then(onload).catch(onerror);
    };
  var FS = {
  root:null,
  mounts:[],
  devices:{
  },
  streams:[],
  nextInode:1,
  nameTable:null,
  currentPath:"/",
  initialized:false,
  ignorePermissions:true,
  filesystems:null,
  syncFSRequests:0,
  ErrnoError:class {
        name = 'ErrnoError';
        // We set the `name` property to be able to identify `FS.ErrnoError`
        // - the `name` is a standard ECMA-262 property of error objects. Kind of good to have it anyway.
        // - when using PROXYFS, an error can come from an underlying FS
        // as different FS objects have their own FS.ErrnoError each,
        // the test `err instanceof FS.ErrnoError` won't detect an error coming from another filesystem, causing bugs.
        // we'll use the reliable test `err.name == "ErrnoError"` instead
        constructor(errno) {
          this.errno = errno;
        }
      },
  FSStream:class {
        shared = {};
        get object() {
          return this.node;
        }
        set object(val) {
          this.node = val;
        }
        get isRead() {
          return (this.flags & 2097155) !== 1;
        }
        get isWrite() {
          return (this.flags & 2097155) !== 0;
        }
        get isAppend() {
          return (this.flags & 1024);
        }
        get flags() {
          return this.shared.flags;
        }
        set flags(val) {
          this.shared.flags = val;
        }
        get position() {
          return this.shared.position;
        }
        set position(val) {
          this.shared.position = val;
        }
      },
  FSNode:class {
        node_ops = {};
        stream_ops = {};
        readMode = 292 | 73;
        writeMode = 146;
        mounted = null;
        constructor(parent, name, mode, rdev) {
          if (!parent) {
            parent = this;  // root node sets parent to itself
          }
          this.parent = parent;
          this.mount = parent.mount;
          this.id = FS.nextInode++;
          this.name = name;
          this.mode = mode;
          this.rdev = rdev;
          this.atime = this.mtime = this.ctime = Date.now();
        }
        get read() {
          return (this.mode & this.readMode) === this.readMode;
        }
        set read(val) {
          val ? this.mode |= this.readMode : this.mode &= ~this.readMode;
        }
        get write() {
          return (this.mode & this.writeMode) === this.writeMode;
        }
        set write(val) {
          val ? this.mode |= this.writeMode : this.mode &= ~this.writeMode;
        }
        get isFolder() {
          return FS.isDir(this.mode);
        }
        get isDevice() {
          return FS.isChrdev(this.mode);
        }
      },
  lookupPath(path, opts = {}) {
        if (!path) {
          throw new FS.ErrnoError(44);
        }
        opts.follow_mount ??= true
  
        if (!PATH.isAbs(path)) {
          path = FS.cwd() + '/' + path;
        }
  
        // limit max consecutive symlinks to SYMLOOP_MAX.
        linkloop: for (var nlinks = 0; nlinks < 40; nlinks++) {
          // split the absolute path
          var parts = path.split('/').filter((p) => !!p);
  
          // start at the root
          var current = FS.root;
          var current_path = '/';
  
          for (var i = 0; i < parts.length; i++) {
            var islast = (i === parts.length-1);
            if (islast && opts.parent) {
              // stop resolving
              break;
            }
  
            if (parts[i] === '.') {
              continue;
            }
  
            if (parts[i] === '..') {
              current_path = PATH.dirname(current_path);
              if (FS.isRoot(current)) {
                path = current_path + '/' + parts.slice(i + 1).join('/');
                // We're making progress here, don't let many consecutive ..'s
                // lead to ELOOP
                nlinks--;
                continue linkloop;
              } else {
                current = current.parent;
              }
              continue;
            }
  
            current_path = PATH.join2(current_path, parts[i]);
            try {
              current = FS.lookupNode(current, parts[i]);
            } catch (e) {
              // if noent_okay is true, suppress a ENOENT in the last component
              // and return an object with an undefined node. This is needed for
              // resolving symlinks in the path when creating a file.
              if ((e?.errno === 44) && islast && opts.noent_okay) {
                return { path: current_path };
              }
              throw e;
            }
  
            // jump to the mount's root node if this is a mountpoint
            if (FS.isMountpoint(current) && (!islast || opts.follow_mount)) {
              current = current.mounted.root;
            }
  
            // by default, lookupPath will not follow a symlink if it is the final path component.
            // setting opts.follow = true will override this behavior.
            if (FS.isLink(current.mode) && (!islast || opts.follow)) {
              if (!current.node_ops.readlink) {
                throw new FS.ErrnoError(52);
              }
              var link = current.node_ops.readlink(current);
              if (!PATH.isAbs(link)) {
                link = PATH.dirname(current_path) + '/' + link;
              }
              path = link + '/' + parts.slice(i + 1).join('/');
              continue linkloop;
            }
          }
          return { path: current_path, node: current };
        }
        throw new FS.ErrnoError(32);
      },
  getPath(node) {
        var path;
        while (true) {
          if (FS.isRoot(node)) {
            var mount = node.mount.mountpoint;
            if (!path) return mount;
            return mount[mount.length-1] !== '/' ? `${mount}/${path}` : mount + path;
          }
          path = path ? `${node.name}/${path}` : node.name;
          node = node.parent;
        }
      },
  hashName(parentid, name) {
        var hash = 0;
  
        for (var i = 0; i < name.length; i++) {
          hash = ((hash << 5) - hash + name.charCodeAt(i)) | 0;
        }
        return ((parentid + hash) >>> 0) % FS.nameTable.length;
      },
  hashAddNode(node) {
        var hash = FS.hashName(node.parent.id, node.name);
        node.name_next = FS.nameTable[hash];
        FS.nameTable[hash] = node;
      },
  hashRemoveNode(node) {
        var hash = FS.hashName(node.parent.id, node.name);
        if (FS.nameTable[hash] === node) {
          FS.nameTable[hash] = node.name_next;
        } else {
          var current = FS.nameTable[hash];
          while (current) {
            if (current.name_next === node) {
              current.name_next = node.name_next;
              break;
            }
            current = current.name_next;
          }
        }
      },
  lookupNode(parent, name) {
        var errCode = FS.mayLookup(parent);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        var hash = FS.hashName(parent.id, name);
        for (var node = FS.nameTable[hash]; node; node = node.name_next) {
          var nodeName = node.name;
          if (node.parent.id === parent.id && nodeName === name) {
            return node;
          }
        }
        // if we failed to find it in the cache, call into the VFS
        return FS.lookup(parent, name);
      },
  createNode(parent, name, mode, rdev) {
        var node = new FS.FSNode(parent, name, mode, rdev);
  
        FS.hashAddNode(node);
  
        return node;
      },
  destroyNode(node) {
        FS.hashRemoveNode(node);
      },
  isRoot(node) {
        return node === node.parent;
      },
  isMountpoint(node) {
        return !!node.mounted;
      },
  isFile(mode) {
        return (mode & 61440) === 32768;
      },
  isDir(mode) {
        return (mode & 61440) === 16384;
      },
  isLink(mode) {
        return (mode & 61440) === 40960;
      },
  isChrdev(mode) {
        return (mode & 61440) === 8192;
      },
  isBlkdev(mode) {
        return (mode & 61440) === 24576;
      },
  isFIFO(mode) {
        return (mode & 61440) === 4096;
      },
  isSocket(mode) {
        return (mode & 49152) === 49152;
      },
  flagsToPermissionString(flag) {
        var perms = ['r', 'w', 'rw'][flag & 3];
        if ((flag & 512)) {
          perms += 'w';
        }
        return perms;
      },
  nodePermissions(node, perms) {
        if (FS.ignorePermissions) {
          return 0;
        }
        // return 0 if any user, group or owner bits are set.
        if (perms.includes('r') && !(node.mode & 292)) {
          return 2;
        }
        if (perms.includes('w') && !(node.mode & 146)) {
          return 2;
        }
        if (perms.includes('x') && !(node.mode & 73)) {
          return 2;
        }
        return 0;
      },
  mayLookup(dir) {
        if (!FS.isDir(dir.mode)) return 54;
        var errCode = FS.nodePermissions(dir, 'x');
        if (errCode) return errCode;
        if (!dir.node_ops.lookup) return 2;
        return 0;
      },
  mayCreate(dir, name) {
        if (!FS.isDir(dir.mode)) {
          return 54;
        }
        try {
          var node = FS.lookupNode(dir, name);
          return 20;
        } catch (e) {
        }
        return FS.nodePermissions(dir, 'wx');
      },
  mayDelete(dir, name, isdir) {
        var node;
        try {
          node = FS.lookupNode(dir, name);
        } catch (e) {
          return e.errno;
        }
        var errCode = FS.nodePermissions(dir, 'wx');
        if (errCode) {
          return errCode;
        }
        if (isdir) {
          if (!FS.isDir(node.mode)) {
            return 54;
          }
          if (FS.isRoot(node) || FS.getPath(node) === FS.cwd()) {
            return 10;
          }
        } else if (FS.isDir(node.mode)) {
          return 31;
        }
        return 0;
      },
  mayOpen(node, flags) {
        if (!node) {
          return 44;
        }
        if (FS.isLink(node.mode)) {
          return 32;
        }
        var mode = FS.flagsToPermissionString(flags);
        if (FS.isDir(node.mode)) {
          // opening for write
          // TODO: check for O_SEARCH? (== search for dir only)
          if (mode !== 'r' || (flags & (512 | 64))) {
            return 31;
          }
        }
        return FS.nodePermissions(node, mode);
      },
  checkOpExists(op, err) {
        if (!op) {
          throw new FS.ErrnoError(err);
        }
        return op;
      },
  MAX_OPEN_FDS:4096,
  nextfd() {
        for (var fd = 0; fd <= FS.MAX_OPEN_FDS; fd++) {
          if (!FS.streams[fd]) {
            return fd;
          }
        }
        throw new FS.ErrnoError(33);
      },
  getStreamChecked(fd) {
        var stream = FS.getStream(fd);
        if (!stream) {
          throw new FS.ErrnoError(8);
        }
        return stream;
      },
  getStream:(fd) => FS.streams[fd],
  createStream(stream, fd = -1) {
  
        // clone it, so we can return an instance of FSStream
        stream = Object.assign(new FS.FSStream(), stream);
        if (fd == -1) {
          fd = FS.nextfd();
        }
        stream.fd = fd;
        FS.streams[fd] = stream;
        return stream;
      },
  closeStream(fd) {
        FS.streams[fd] = null;
      },
  dupStream(origStream, fd = -1) {
        var stream = FS.createStream(origStream, fd);
        stream.stream_ops?.dup?.(stream);
        return stream;
      },
  doSetAttr(stream, node, attr) {
        var setattr = stream?.stream_ops.setattr;
        var arg = setattr ? stream : node;
        setattr ??= node.node_ops.setattr;
        FS.checkOpExists(setattr, 63)
        try {
          setattr(arg, attr);
        } catch (e) {
          if (e instanceof RangeError) {
            throw new FS.ErrnoError(22);
          }
          throw e;
        }
      },
  chrdev_stream_ops:{
  open(stream) {
          var device = FS.getDevice(stream.node.rdev);
          // override node's stream ops with the device's
          stream.stream_ops = device.stream_ops;
          // forward the open call
          stream.stream_ops.open?.(stream);
        },
  llseek() {
          throw new FS.ErrnoError(70);
        },
  },
  major:(dev) => ((dev) >> 8),
  minor:(dev) => ((dev) & 0xff),
  makedev:(ma, mi) => ((ma) << 8 | (mi)),
  registerDevice(dev, ops) {
        FS.devices[dev] = { stream_ops: ops };
      },
  getDevice:(dev) => FS.devices[dev],
  getMounts(mount) {
        var mounts = [];
        var check = [mount];
  
        while (check.length) {
          var m = check.pop();
  
          mounts.push(m);
  
          check.push(...m.mounts);
        }
  
        return mounts;
      },
  syncfs(populate, callback) {
        if (typeof populate == 'function') {
          callback = populate;
          populate = false;
        }
  
        FS.syncFSRequests++;
  
        if (FS.syncFSRequests > 1) {
          err(`warning: ${FS.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);
        }
  
        var mounts = FS.getMounts(FS.root.mount);
        var completed = 0;
  
        function doCallback(errCode) {
          FS.syncFSRequests--;
          return callback(errCode);
        }
  
        function done(errCode) {
          if (errCode) {
            if (!done.errored) {
              done.errored = true;
              return doCallback(errCode);
            }
            return;
          }
          if (++completed >= mounts.length) {
            doCallback(null);
          }
        };
  
        // sync all mounts
        for (var mount of mounts) {
          if (mount.type.syncfs) {
            mount.type.syncfs(mount, populate, done);
          } else {
            done(null);
          }
        }
      },
  mount(type, opts, mountpoint) {
        var root = mountpoint === '/';
        var pseudo = !mountpoint;
        var node;
  
        if (root && FS.root) {
          throw new FS.ErrnoError(10);
        } else if (!root && !pseudo) {
          var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
  
          mountpoint = lookup.path;  // use the absolute path
          node = lookup.node;
  
          if (FS.isMountpoint(node)) {
            throw new FS.ErrnoError(10);
          }
  
          if (!FS.isDir(node.mode)) {
            throw new FS.ErrnoError(54);
          }
        }
  
        var mount = {
          type,
          opts,
          mountpoint,
          mounts: []
        };
  
        // create a root node for the fs
        var mountRoot = type.mount(mount);
        mountRoot.mount = mount;
        mount.root = mountRoot;
  
        if (root) {
          FS.root = mountRoot;
        } else if (node) {
          // set as a mountpoint
          node.mounted = mount;
  
          // add the new mount to the current mount's children
          if (node.mount) {
            node.mount.mounts.push(mount);
          }
        }
  
        return mountRoot;
      },
  unmount(mountpoint) {
        var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
  
        if (!FS.isMountpoint(lookup.node)) {
          throw new FS.ErrnoError(28);
        }
  
        // destroy the nodes for this mount, and all its child mounts
        var node = lookup.node;
        var mount = node.mounted;
        var mounts = FS.getMounts(mount);
  
        for (var [hash, current] of Object.entries(FS.nameTable)) {
          while (current) {
            var next = current.name_next;
  
            if (mounts.includes(current.mount)) {
              FS.destroyNode(current);
            }
  
            current = next;
          }
        }
  
        // no longer a mountpoint
        node.mounted = null;
  
        // remove this mount from the child mounts
        var idx = node.mount.mounts.indexOf(mount);
        node.mount.mounts.splice(idx, 1);
      },
  lookup(parent, name) {
        return parent.node_ops.lookup(parent, name);
      },
  mknod(path, mode, dev) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        var name = PATH.basename(path);
        if (!name) {
          throw new FS.ErrnoError(28);
        }
        if (name === '.' || name === '..') {
          throw new FS.ErrnoError(20);
        }
        var errCode = FS.mayCreate(parent, name);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.mknod) {
          throw new FS.ErrnoError(63);
        }
        return parent.node_ops.mknod(parent, name, mode, dev);
      },
  statfs(path) {
        return FS.statfsNode(FS.lookupPath(path, {follow: true}).node);
      },
  statfsStream(stream) {
        // We keep a separate statfsStream function because noderawfs overrides
        // it. In noderawfs, stream.node is sometimes null. Instead, we need to
        // look at stream.path.
        return FS.statfsNode(stream.node);
      },
  statfsNode(node) {
        // NOTE: None of the defaults here are true. We're just returning safe and
        //       sane values. Currently nodefs and rawfs replace these defaults,
        //       other file systems leave them alone.
        var rtn = {
          bsize: 4096,
          frsize: 4096,
          blocks: 1e6,
          bfree: 5e5,
          bavail: 5e5,
          files: FS.nextInode,
          ffree: FS.nextInode - 1,
          fsid: 42,
          flags: 2,
          namelen: 255,
        };
  
        if (node.node_ops.statfs) {
          Object.assign(rtn, node.node_ops.statfs(node.mount.opts.root));
        }
        return rtn;
      },
  create(path, mode = 0o666) {
        mode &= 4095;
        mode |= 32768;
        return FS.mknod(path, mode, 0);
      },
  mkdir(path, mode = 0o777) {
        mode &= 511 | 512;
        mode |= 16384;
        return FS.mknod(path, mode, 0);
      },
  mkdirTree(path, mode) {
        var dirs = path.split('/');
        var d = '';
        for (var dir of dirs) {
          if (!dir) continue;
          if (d || PATH.isAbs(path)) d += '/';
          d += dir;
          try {
            FS.mkdir(d, mode);
          } catch(e) {
            if (e.errno != 20) throw e;
          }
        }
      },
  mkdev(path, mode, dev) {
        if (typeof dev == 'undefined') {
          dev = mode;
          mode = 0o666;
        }
        mode |= 8192;
        return FS.mknod(path, mode, dev);
      },
  symlink(oldpath, newpath) {
        if (!PATH_FS.resolve(oldpath)) {
          throw new FS.ErrnoError(44);
        }
        var lookup = FS.lookupPath(newpath, { parent: true });
        var parent = lookup.node;
        if (!parent) {
          throw new FS.ErrnoError(44);
        }
        var newname = PATH.basename(newpath);
        var errCode = FS.mayCreate(parent, newname);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.symlink) {
          throw new FS.ErrnoError(63);
        }
        return parent.node_ops.symlink(parent, newname, oldpath);
      },
  rename(old_path, new_path) {
        var old_dirname = PATH.dirname(old_path);
        var new_dirname = PATH.dirname(new_path);
        var old_name = PATH.basename(old_path);
        var new_name = PATH.basename(new_path);
        // parents must exist
        var lookup, old_dir, new_dir;
  
        // let the errors from non existent directories percolate up
        lookup = FS.lookupPath(old_path, { parent: true });
        old_dir = lookup.node;
        lookup = FS.lookupPath(new_path, { parent: true });
        new_dir = lookup.node;
  
        if (!old_dir || !new_dir) throw new FS.ErrnoError(44);
        // need to be part of the same mount
        if (old_dir.mount !== new_dir.mount) {
          throw new FS.ErrnoError(75);
        }
        // source must exist
        var old_node = FS.lookupNode(old_dir, old_name);
        // old path should not be an ancestor of the new path
        var relative = PATH_FS.relative(old_path, new_dirname);
        if (relative.charAt(0) !== '.') {
          throw new FS.ErrnoError(28);
        }
        // new path should not be an ancestor of the old path
        relative = PATH_FS.relative(new_path, old_dirname);
        if (relative.charAt(0) !== '.') {
          throw new FS.ErrnoError(55);
        }
        // see if the new path already exists
        var new_node;
        try {
          new_node = FS.lookupNode(new_dir, new_name);
        } catch (e) {
          // not fatal
        }
        // early out if nothing needs to change
        if (old_node === new_node) {
          return;
        }
        // we'll need to delete the old entry
        var isdir = FS.isDir(old_node.mode);
        var errCode = FS.mayDelete(old_dir, old_name, isdir);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        // need delete permissions if we'll be overwriting.
        // need create permissions if new doesn't already exist.
        errCode = new_node ?
          FS.mayDelete(new_dir, new_name, isdir) :
          FS.mayCreate(new_dir, new_name);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!old_dir.node_ops.rename) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(old_node) || (new_node && FS.isMountpoint(new_node))) {
          throw new FS.ErrnoError(10);
        }
        // if we are going to change the parent, check write permissions
        if (new_dir !== old_dir) {
          errCode = FS.nodePermissions(old_dir, 'w');
          if (errCode) {
            throw new FS.ErrnoError(errCode);
          }
        }
        // remove the node from the lookup hash
        FS.hashRemoveNode(old_node);
        // do the underlying fs rename
        try {
          old_dir.node_ops.rename(old_node, new_dir, new_name);
          // update old node (we do this here to avoid each backend
          // needing to)
          old_node.parent = new_dir;
        } catch (e) {
          throw e;
        } finally {
          // add the node back to the hash (in case node_ops.rename
          // changed its name)
          FS.hashAddNode(old_node);
        }
      },
  rmdir(path) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        var name = PATH.basename(path);
        var node = FS.lookupNode(parent, name);
        var errCode = FS.mayDelete(parent, name, true);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.rmdir) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(node)) {
          throw new FS.ErrnoError(10);
        }
        parent.node_ops.rmdir(parent, name);
        FS.destroyNode(node);
      },
  readdir(path) {
        var lookup = FS.lookupPath(path, { follow: true });
        var node = lookup.node;
        var readdir = FS.checkOpExists(node.node_ops.readdir, 54);
        return readdir(node);
      },
  unlink(path) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        if (!parent) {
          throw new FS.ErrnoError(44);
        }
        var name = PATH.basename(path);
        var node = FS.lookupNode(parent, name);
        var errCode = FS.mayDelete(parent, name, false);
        if (errCode) {
          // According to POSIX, we should map EISDIR to EPERM, but
          // we instead do what Linux does (and we must, as we use
          // the musl linux libc).
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.unlink) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(node)) {
          throw new FS.ErrnoError(10);
        }
        parent.node_ops.unlink(parent, name);
        FS.destroyNode(node);
      },
  readlink(path) {
        var lookup = FS.lookupPath(path);
        var link = lookup.node;
        if (!link) {
          throw new FS.ErrnoError(44);
        }
        if (!link.node_ops.readlink) {
          throw new FS.ErrnoError(28);
        }
        return link.node_ops.readlink(link);
      },
  stat(path, dontFollow) {
        var lookup = FS.lookupPath(path, { follow: !dontFollow });
        var node = lookup.node;
        var getattr = FS.checkOpExists(node.node_ops.getattr, 63);
        return getattr(node);
      },
  fstat(fd) {
        var stream = FS.getStreamChecked(fd);
        var node = stream.node;
        var getattr = stream.stream_ops.getattr;
        var arg = getattr ? stream : node;
        getattr ??= node.node_ops.getattr;
        FS.checkOpExists(getattr, 63)
        return getattr(arg);
      },
  lstat(path) {
        return FS.stat(path, true);
      },
  doChmod(stream, node, mode, dontFollow) {
        FS.doSetAttr(stream, node, {
          mode: (mode & 4095) | (node.mode & ~4095),
          ctime: Date.now(),
          dontFollow
        });
      },
  chmod(path, mode, dontFollow) {
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: !dontFollow });
          node = lookup.node;
        } else {
          node = path;
        }
        FS.doChmod(null, node, mode, dontFollow);
      },
  lchmod(path, mode) {
        FS.chmod(path, mode, true);
      },
  fchmod(fd, mode) {
        var stream = FS.getStreamChecked(fd);
        FS.doChmod(stream, stream.node, mode, false);
      },
  doChown(stream, node, dontFollow) {
        FS.doSetAttr(stream, node, {
          timestamp: Date.now(),
          dontFollow
          // we ignore the uid / gid for now
        });
      },
  chown(path, uid, gid, dontFollow) {
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: !dontFollow });
          node = lookup.node;
        } else {
          node = path;
        }
        FS.doChown(null, node, dontFollow);
      },
  lchown(path, uid, gid) {
        FS.chown(path, uid, gid, true);
      },
  fchown(fd, uid, gid) {
        var stream = FS.getStreamChecked(fd);
        FS.doChown(stream, stream.node, false);
      },
  doTruncate(stream, node, len) {
        if (FS.isDir(node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!FS.isFile(node.mode)) {
          throw new FS.ErrnoError(28);
        }
        var errCode = FS.nodePermissions(node, 'w');
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        FS.doSetAttr(stream, node, {
          size: len,
          timestamp: Date.now()
        });
      },
  truncate(path, len) {
        if (len < 0) {
          throw new FS.ErrnoError(28);
        }
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: true });
          node = lookup.node;
        } else {
          node = path;
        }
        FS.doTruncate(null, node, len);
      },
  ftruncate(fd, len) {
        var stream = FS.getStreamChecked(fd);
        if (len < 0 || (stream.flags & 2097155) === 0) {
          throw new FS.ErrnoError(28);
        }
        FS.doTruncate(stream, stream.node, len);
      },
  utime(path, atime, mtime) {
        var lookup = FS.lookupPath(path, { follow: true });
        var node = lookup.node;
        var setattr = FS.checkOpExists(node.node_ops.setattr, 63);
        setattr(node, {
          atime: atime,
          mtime: mtime
        });
      },
  open(path, flags, mode = 0o666) {
        if (path === "") {
          throw new FS.ErrnoError(44);
        }
        flags = FS_modeStringToFlags(flags);
        if ((flags & 64)) {
          mode = (mode & 4095) | 32768;
        } else {
          mode = 0;
        }
        var node;
        var isDirPath;
        if (typeof path == 'object') {
          node = path;
        } else {
          isDirPath = path.endsWith("/");
          // noent_okay makes it so that if the final component of the path
          // doesn't exist, lookupPath returns `node: undefined`. `path` will be
          // updated to point to the target of all symlinks.
          var lookup = FS.lookupPath(path, {
            follow: !(flags & 131072),
            noent_okay: true
          });
          node = lookup.node;
          path = lookup.path;
        }
        // perhaps we need to create the node
        var created = false;
        if ((flags & 64)) {
          if (node) {
            // if O_CREAT and O_EXCL are set, error out if the node already exists
            if ((flags & 128)) {
              throw new FS.ErrnoError(20);
            }
          } else if (isDirPath) {
            throw new FS.ErrnoError(31);
          } else {
            // node doesn't exist, try to create it
            // Ignore the permission bits here to ensure we can `open` this new
            // file below. We use chmod below to apply the permissions once the
            // file is open.
            node = FS.mknod(path, mode | 0o777, 0);
            created = true;
          }
        }
        if (!node) {
          throw new FS.ErrnoError(44);
        }
        // can't truncate a device
        if (FS.isChrdev(node.mode)) {
          flags &= ~512;
        }
        // if asked only for a directory, then this must be one
        if ((flags & 65536) && !FS.isDir(node.mode)) {
          throw new FS.ErrnoError(54);
        }
        // check permissions, if this is not a file we just created now (it is ok to
        // create and write to a file with read-only permissions; it is read-only
        // for later use)
        if (!created) {
          var errCode = FS.mayOpen(node, flags);
          if (errCode) {
            throw new FS.ErrnoError(errCode);
          }
        }
        // do truncation if necessary
        if ((flags & 512) && !created) {
          FS.truncate(node, 0);
        }
        // we've already handled these, don't pass down to the underlying vfs
        flags &= ~(128 | 512 | 131072);
  
        // register the stream with the filesystem
        var stream = FS.createStream({
          node,
          path: FS.getPath(node),  // we want the absolute path to the node
          flags,
          seekable: true,
          position: 0,
          stream_ops: node.stream_ops,
          // used by the file family libc calls (fopen, fwrite, ferror, etc.)
          ungotten: [],
          error: false
        });
        // call the new stream's open function
        if (stream.stream_ops.open) {
          stream.stream_ops.open(stream);
        }
        if (created) {
          FS.chmod(node, mode & 0o777);
        }
        return stream;
      },
  close(stream) {
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if (stream.getdents) stream.getdents = null; // free readdir state
        try {
          if (stream.stream_ops.close) {
            stream.stream_ops.close(stream);
          }
        } catch (e) {
          throw e;
        } finally {
          FS.closeStream(stream.fd);
        }
        stream.fd = null;
      },
  isClosed(stream) {
        return stream.fd === null;
      },
  llseek(stream, offset, whence) {
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if (!stream.seekable || !stream.stream_ops.llseek) {
          throw new FS.ErrnoError(70);
        }
        if (whence != 0 && whence != 1 && whence != 2) {
          throw new FS.ErrnoError(28);
        }
        stream.position = stream.stream_ops.llseek(stream, offset, whence);
        stream.ungotten = [];
        return stream.position;
      },
  read(stream, buffer, offset, length, position) {
        if (length < 0 || position < 0) {
          throw new FS.ErrnoError(28);
        }
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if ((stream.flags & 2097155) === 1) {
          throw new FS.ErrnoError(8);
        }
        if (FS.isDir(stream.node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!stream.stream_ops.read) {
          throw new FS.ErrnoError(28);
        }
        var seeking = typeof position != 'undefined';
        if (!seeking) {
          position = stream.position;
        } else if (!stream.seekable) {
          throw new FS.ErrnoError(70);
        }
        var bytesRead = stream.stream_ops.read(stream, buffer, offset, length, position);
        if (!seeking) stream.position += bytesRead;
        return bytesRead;
      },
  write(stream, buffer, offset, length, position, canOwn) {
        if (length < 0 || position < 0) {
          throw new FS.ErrnoError(28);
        }
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if ((stream.flags & 2097155) === 0) {
          throw new FS.ErrnoError(8);
        }
        if (FS.isDir(stream.node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!stream.stream_ops.write) {
          throw new FS.ErrnoError(28);
        }
        if (stream.seekable && stream.flags & 1024) {
          // seek to the end before writing in append mode
          FS.llseek(stream, 0, 2);
        }
        var seeking = typeof position != 'undefined';
        if (!seeking) {
          position = stream.position;
        } else if (!stream.seekable) {
          throw new FS.ErrnoError(70);
        }
        var bytesWritten = stream.stream_ops.write(stream, buffer, offset, length, position, canOwn);
        if (!seeking) stream.position += bytesWritten;
        return bytesWritten;
      },
  mmap(stream, length, position, prot, flags) {
        // User requests writing to file (prot & PROT_WRITE != 0).
        // Checking if we have permissions to write to the file unless
        // MAP_PRIVATE flag is set. According to POSIX spec it is possible
        // to write to file opened in read-only mode with MAP_PRIVATE flag,
        // as all modifications will be visible only in the memory of
        // the current process.
        if ((prot & 2) !== 0
            && (flags & 2) === 0
            && (stream.flags & 2097155) !== 2) {
          throw new FS.ErrnoError(2);
        }
        if ((stream.flags & 2097155) === 1) {
          throw new FS.ErrnoError(2);
        }
        if (!stream.stream_ops.mmap) {
          throw new FS.ErrnoError(43);
        }
        if (!length) {
          throw new FS.ErrnoError(28);
        }
        return stream.stream_ops.mmap(stream, length, position, prot, flags);
      },
  msync(stream, buffer, offset, length, mmapFlags) {
        if (!stream.stream_ops.msync) {
          return 0;
        }
        return stream.stream_ops.msync(stream, buffer, offset, length, mmapFlags);
      },
  ioctl(stream, cmd, arg) {
        if (!stream.stream_ops.ioctl) {
          throw new FS.ErrnoError(59);
        }
        return stream.stream_ops.ioctl(stream, cmd, arg);
      },
  readFile(path, opts = {}) {
        opts.flags = opts.flags || 0;
        opts.encoding = opts.encoding || 'binary';
        if (opts.encoding !== 'utf8' && opts.encoding !== 'binary') {
          abort(`Invalid encoding type "${opts.encoding}"`);
        }
        var stream = FS.open(path, opts.flags);
        var stat = FS.stat(path);
        var length = stat.size;
        var buf = new Uint8Array(length);
        FS.read(stream, buf, 0, length, 0);
        if (opts.encoding === 'utf8') {
          buf = UTF8ArrayToString(buf);
        }
        FS.close(stream);
        return buf;
      },
  writeFile(path, data, opts = {}) {
        opts.flags = opts.flags || 577;
        var stream = FS.open(path, opts.flags, opts.mode);
        data = FS_fileDataToTypedArray(data);
        FS.write(stream, data, 0, data.byteLength, undefined, opts.canOwn);
        FS.close(stream);
      },
  cwd:() => FS.currentPath,
  chdir(path) {
        var lookup = FS.lookupPath(path, { follow: true });
        if (lookup.node === null) {
          throw new FS.ErrnoError(44);
        }
        if (!FS.isDir(lookup.node.mode)) {
          throw new FS.ErrnoError(54);
        }
        var errCode = FS.nodePermissions(lookup.node, 'x');
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        FS.currentPath = lookup.path;
      },
  createDefaultDirectories() {
        FS.mkdir('/tmp');
        FS.mkdir('/home');
        FS.mkdir('/home/web_user');
      },
  createDefaultDevices() {
        // create /dev
        FS.mkdir('/dev');
        // setup /dev/null
        FS.registerDevice(FS.makedev(1, 3), {
          read: () => 0,
          write: (stream, buffer, offset, length, pos) => length,
          llseek: () => 0,
        });
        FS.mkdev('/dev/null', FS.makedev(1, 3));
        // setup /dev/tty and /dev/tty1
        // stderr needs to print output using err() rather than out()
        // so we register a second tty just for it.
        TTY.register(FS.makedev(5, 0), TTY.default_tty_ops);
        TTY.register(FS.makedev(6, 0), TTY.default_tty1_ops);
        FS.mkdev('/dev/tty', FS.makedev(5, 0));
        FS.mkdev('/dev/tty1', FS.makedev(6, 0));
        // setup /dev/[u]random
        // use a buffer to avoid overhead of individual crypto calls per byte
        var randomBuffer = new Uint8Array(1024), randomLeft = 0;
        var randomByte = () => {
          if (randomLeft === 0) {
            randomFill(randomBuffer);
            randomLeft = randomBuffer.byteLength;
          }
          return randomBuffer[--randomLeft];
        };
        FS.createDevice('/dev', 'random', randomByte);
        FS.createDevice('/dev', 'urandom', randomByte);
        // we're not going to emulate the actual shm device,
        // just create the tmp dirs that reside in it commonly
        FS.mkdir('/dev/shm');
        FS.mkdir('/dev/shm/tmp');
      },
  createSpecialDirectories() {
        // create /proc/self/fd which allows /proc/self/fd/6 => readlink gives the
        // name of the stream for fd 6 (see test_unistd_ttyname)
        FS.mkdir('/proc');
        var proc_self = FS.mkdir('/proc/self');
        FS.mkdir('/proc/self/fd');
        FS.mount({
          mount() {
            var node = FS.createNode(proc_self, 'fd', 16895, 73);
            node.stream_ops = {
              llseek: MEMFS.stream_ops.llseek,
            };
            node.node_ops = {
              lookup(parent, name) {
                var fd = +name;
                var stream = FS.getStreamChecked(fd);
                var ret = {
                  parent: null,
                  mount: { mountpoint: 'fake' },
                  node_ops: { readlink: () => stream.path },
                  id: fd + 1,
                };
                ret.parent = ret; // make it look like a simple root node
                return ret;
              },
              readdir() {
                return Array.from(FS.streams.entries())
                  .filter(([k, v]) => v)
                  .map(([k, v]) => k.toString());
              }
            };
            return node;
          }
        }, {}, '/proc/self/fd');
      },
  createStandardStreams(input, output, error) {
        // TODO deprecate the old functionality of a single
        // input / output callback and that utilizes FS.createDevice
        // and instead require a unique set of stream ops
  
        // by default, we symlink the standard streams to the
        // default tty devices. however, if the standard streams
        // have been overwritten we create a unique device for
        // them instead.
        if (input) {
          FS.createDevice('/dev', 'stdin', input);
        } else {
          FS.symlink('/dev/tty', '/dev/stdin');
        }
        if (output) {
          FS.createDevice('/dev', 'stdout', null, output);
        } else {
          FS.symlink('/dev/tty', '/dev/stdout');
        }
        if (error) {
          FS.createDevice('/dev', 'stderr', null, error);
        } else {
          FS.symlink('/dev/tty1', '/dev/stderr');
        }
  
        // open default streams for the stdin, stdout and stderr devices
        var stdin = FS.open('/dev/stdin', 0);
        var stdout = FS.open('/dev/stdout', 1);
        var stderr = FS.open('/dev/stderr', 1);
      },
  staticInit() {
        FS.nameTable = new Array(4096);
  
        FS.mount(MEMFS, {}, '/');
  
        FS.createDefaultDirectories();
        FS.createDefaultDevices();
        FS.createSpecialDirectories();
  
        FS.filesystems = {
          'MEMFS': MEMFS,
        };
      },
  init(input, output, error) {
        FS.initialized = true;
  
        // Allow Module.stdin etc. to provide defaults, if none explicitly passed to us here
        input ??= Module['stdin'];
        output ??= Module['stdout'];
        error ??= Module['stderr'];
  
        FS.createStandardStreams(input, output, error);
      },
  quit() {
        FS.initialized = false;
        // force-flush all streams, so we get musl std streams printed out
        _fflush(0);
        // close all of our streams
        for (var stream of FS.streams) {
          if (stream) {
            FS.close(stream);
          }
        }
      },
  findObject(path, dontResolveLastLink) {
        var ret = FS.analyzePath(path, dontResolveLastLink);
        if (!ret.exists) {
          return null;
        }
        return ret.object;
      },
  analyzePath(path, dontResolveLastLink) {
        // operate from within the context of the symlink's target
        try {
          var lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
          path = lookup.path;
        } catch (e) {
        }
        var ret = {
          isRoot: false, exists: false, error: 0, name: null, path: null, object: null,
          parentExists: false, parentPath: null, parentObject: null
        };
        try {
          var lookup = FS.lookupPath(path, { parent: true });
          ret.parentExists = true;
          ret.parentPath = lookup.path;
          ret.parentObject = lookup.node;
          ret.name = PATH.basename(path);
          lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
          ret.exists = true;
          ret.path = lookup.path;
          ret.object = lookup.node;
          ret.name = lookup.node.name;
          ret.isRoot = lookup.path === '/';
        } catch (e) {
          ret.error = e.errno;
        };
        return ret;
      },
  createPath(parent, path, canRead, canWrite) {
        parent = typeof parent == 'string' ? parent : FS.getPath(parent);
        var parts = path.split('/').reverse();
        while (parts.length) {
          var part = parts.pop();
          if (!part) continue;
          var current = PATH.join2(parent, part);
          try {
            FS.mkdir(current);
          } catch (e) {
            if (e.errno != 20) throw e;
          }
          parent = current;
        }
        return current;
      },
  createFile(parent, name, properties, canRead, canWrite) {
        var path = PATH.join2(typeof parent == 'string' ? parent : FS.getPath(parent), name);
        var mode = FS_getMode(canRead, canWrite);
        return FS.create(path, mode);
      },
  createDataFile(parent, name, data, canRead, canWrite, canOwn) {
        var path = name;
        if (parent) {
          parent = typeof parent == 'string' ? parent : FS.getPath(parent);
          path = name ? PATH.join2(parent, name) : parent;
        }
        var mode = FS_getMode(canRead, canWrite);
        var node = FS.create(path, mode);
        if (data) {
          data = FS_fileDataToTypedArray(data);
          // make sure we can write to the file
          FS.chmod(node, mode | 146);
          var stream = FS.open(node, 577);
          FS.write(stream, data, 0, data.length, 0, canOwn);
          FS.close(stream);
          FS.chmod(node, mode);
        }
      },
  createDevice(parent, name, input, output) {
        var path = PATH.join2(typeof parent == 'string' ? parent : FS.getPath(parent), name);
        var mode = FS_getMode(!!input, !!output);
        FS.createDevice.major ??= 64;
        var dev = FS.makedev(FS.createDevice.major++, 0);
        // Create a fake device that a set of stream ops to emulate
        // the old behavior.
        FS.registerDevice(dev, {
          open(stream) {
            stream.seekable = false;
          },
          close(stream) {
            // flush any pending line data
            if (output?.buffer?.length) {
              output(10);
            }
          },
          read(stream, buffer, offset, length, pos /* ignored */) {
            var bytesRead = 0;
            for (var i = 0; i < length; i++) {
              var result;
              try {
                result = input();
              } catch (e) {
                throw new FS.ErrnoError(29);
              }
              if (result === undefined && bytesRead === 0) {
                throw new FS.ErrnoError(6);
              }
              if (result === null || result === undefined) break;
              bytesRead++;
              buffer[offset+i] = result;
            }
            if (bytesRead) {
              stream.node.atime = Date.now();
            }
            return bytesRead;
          },
          write(stream, buffer, offset, length, pos) {
            for (var i = 0; i < length; i++) {
              try {
                output(buffer[offset+i]);
              } catch (e) {
                throw new FS.ErrnoError(29);
              }
            }
            if (length) {
              stream.node.mtime = stream.node.ctime = Date.now();
            }
            return i;
          }
        });
        return FS.mkdev(path, mode, dev);
      },
  forceLoadFile(obj) {
        if (obj.isDevice || obj.isFolder || obj.link || obj.contents) return true;
        if (globalThis.XMLHttpRequest) {
          abort("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
        } else { // Command-line.
          try {
            obj.contents = readBinary(obj.url);
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
        }
      },
  createLazyFile(parent, name, url, canRead, canWrite) {
        // Lazy chunked Uint8Array (implements get and length from Uint8Array).
        // Actual getting is abstracted away for eventual reuse.
        class LazyUint8Array {
          lengthKnown = false;
          chunks = []; // Loaded chunks. Index is the chunk number
          get(idx) {
            if (idx > this.length-1 || idx < 0) {
              return undefined;
            }
            var chunkOffset = idx % this.chunkSize;
            var chunkNum = (idx / this.chunkSize)|0;
            return this.getter(chunkNum)[chunkOffset];
          }
          setDataGetter(getter) {
            this.getter = getter;
          }
          cacheLength() {
            // Find length
            var xhr = new XMLHttpRequest();
            xhr.open('HEAD', url, false);
            xhr.send(null);
            if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) abort("Couldn't load " + url + ". Status: " + xhr.status);
            var datalength = Number(xhr.getResponseHeader("Content-length"));
            var header;
            var hasByteServing = (header = xhr.getResponseHeader("Accept-Ranges")) && header === "bytes";
            var usesGzip = (header = xhr.getResponseHeader("Content-Encoding")) && header === "gzip";
  
            var chunkSize = 1024*1024; // Chunk size in bytes
  
            if (!hasByteServing) chunkSize = datalength;
  
            // Function to get a range from the remote URL.
            var doXHR = (from, to) => {
              if (from > to) abort("invalid range (" + from + ", " + to + ") or no bytes requested!");
              if (to > datalength-1) abort("only " + datalength + " bytes available! programmer error!");
  
              // TODO: Use mozResponseArrayBuffer, responseStream, etc. if available.
              var xhr = new XMLHttpRequest();
              xhr.open('GET', url, false);
              if (datalength !== chunkSize) xhr.setRequestHeader("Range", "bytes=" + from + "-" + to);
  
              // Some hints to the browser that we want binary data.
              xhr.responseType = 'arraybuffer';
              if (xhr.overrideMimeType) {
                xhr.overrideMimeType('text/plain; charset=x-user-defined');
              }
  
              xhr.send(null);
              if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) abort("Couldn't load " + url + ". Status: " + xhr.status);
              if (xhr.response !== undefined) {
                return new Uint8Array(/** @type{Array<number>} */(xhr.response || []));
              }
              return intArrayFromString(xhr.responseText || '', true);
            };
            var lazyArray = this;
            lazyArray.setDataGetter((chunkNum) => {
              var start = chunkNum * chunkSize;
              var end = (chunkNum+1) * chunkSize - 1; // including this byte
              end = Math.min(end, datalength-1); // if datalength-1 is selected, this is the last block
              if (typeof lazyArray.chunks[chunkNum] == 'undefined') {
                lazyArray.chunks[chunkNum] = doXHR(start, end);
              }
              if (typeof lazyArray.chunks[chunkNum] == 'undefined') abort('doXHR failed!');
              return lazyArray.chunks[chunkNum];
            });
  
            if (usesGzip || !datalength) {
              // if the server uses gzip or doesn't supply the length, we have to download the whole file to get the (uncompressed) length
              chunkSize = datalength = 1; // this will force getter(0)/doXHR do download the whole file
              datalength = this.getter(0).length;
              chunkSize = datalength;
              out("LazyFiles on gzip forces download of the whole file when length is accessed");
            }
  
            this._length = datalength;
            this._chunkSize = chunkSize;
            this.lengthKnown = true;
          }
          get length() {
            if (!this.lengthKnown) {
              this.cacheLength();
            }
            return this._length;
          }
          get chunkSize() {
            if (!this.lengthKnown) {
              this.cacheLength();
            }
            return this._chunkSize;
          }
        }
  
        if (globalThis.XMLHttpRequest) {
          if (!ENVIRONMENT_IS_WORKER) abort('Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc');
          var lazyArray = new LazyUint8Array();
          var properties = { isDevice: false, contents: lazyArray };
        } else {
          var properties = { isDevice: false, url: url };
        }
  
        var node = FS.createFile(parent, name, properties, canRead, canWrite);
        // This is a total hack, but I want to get this lazy file code out of the
        // core of MEMFS. If we want to keep this lazy file concept I feel it should
        // be its own thin LAZYFS proxying calls to MEMFS.
        if (properties.contents) {
          node.contents = properties.contents;
        } else if (properties.url) {
          node.contents = null;
          node.url = properties.url;
        }
        // Add a function that defers querying the file size until it is asked the first time.
        Object.defineProperties(node, {
          usedBytes: {
            get: function() { return this.contents.length; }
          }
        });
        // override each stream op with one that tries to force load the lazy file first
        var stream_ops = {};
        for (const [key, fn] of Object.entries(node.stream_ops)) {
          stream_ops[key] = (...args) => {
            FS.forceLoadFile(node);
            return fn(...args);
          };
        }
        function writeChunks(stream, buffer, offset, length, position) {
          var contents = stream.node.contents;
          if (position >= contents.length)
            return 0;
          var size = Math.min(contents.length - position, length);
          if (contents.slice) { // normal array
            for (var i = 0; i < size; i++) {
              buffer[offset + i] = contents[position + i];
            }
          } else {
            for (var i = 0; i < size; i++) { // LazyUint8Array from sync binary XHR
              buffer[offset + i] = contents.get(position + i);
            }
          }
          return size;
        }
        // use a custom read function
        stream_ops.read = (stream, buffer, offset, length, position) => {
          FS.forceLoadFile(node);
          return writeChunks(stream, buffer, offset, length, position)
        };
        // use a custom mmap function
        stream_ops.mmap = (stream, length, position, prot, flags) => {
          FS.forceLoadFile(node);
          var ptr = mmapAlloc(length);
          if (!ptr) {
            throw new FS.ErrnoError(48);
          }
          writeChunks(stream, HEAP8, ptr, length, position);
          return { ptr, allocated: true };
        };
        node.stream_ops = stream_ops;
        return node;
      },
  };
  
  
    /**
   * Given a pointer 'ptr' to a null-terminated UTF8-encoded string in the
   * emscripten HEAP, returns a copy of that string as a Javascript String object.
   *
   * @param {number} ptr
   * @param {number=} maxBytesToRead - An optional length that specifies the
   *   maximum number of bytes to read. You can omit this parameter to scan the
   *   string until the first 0 byte. If maxBytesToRead is passed, and the string
   *   at [ptr, ptr+maxBytesToReadr[ contains a null byte in the middle, then the
   *   string will cut short at that byte index.
   * @param {boolean=} ignoreNul - If true, the function will not stop on a NUL character.
   * @return {string}
   */
  var UTF8ToString = (ptr, maxBytesToRead, ignoreNul) => {
      return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead, ignoreNul) : '';
    };
  var SYSCALLS = {
  currentUmask:18,
  calculateAt(dirfd, path, allowEmpty) {
        if (PATH.isAbs(path)) {
          return path;
        }
        // relative path
        var dir;
        if (dirfd === -100) {
          dir = FS.cwd();
        } else {
          var dirstream = SYSCALLS.getStreamFromFD(dirfd);
          dir = dirstream.path;
        }
        if (path.length == 0) {
          if (!allowEmpty) {
            throw new FS.ErrnoError(44);;
          }
          return dir;
        }
        return dir + '/' + path;
      },
  writeStat(buf, stat) {
        HEAPU32[((buf)>>2)] = stat.dev;
        HEAPU32[(((buf)+(4))>>2)] = stat.mode;
        HEAPU32[(((buf)+(8))>>2)] = stat.nlink;
        HEAPU32[(((buf)+(12))>>2)] = stat.uid;
        HEAPU32[(((buf)+(16))>>2)] = stat.gid;
        HEAPU32[(((buf)+(20))>>2)] = stat.rdev;
        HEAP64[(((buf)+(24))>>3)] = BigInt(stat.size);
        HEAP32[(((buf)+(32))>>2)] = 4096;
        HEAP32[(((buf)+(36))>>2)] = stat.blocks;
        var atime = stat.atime.getTime();
        var mtime = stat.mtime.getTime();
        var ctime = stat.ctime.getTime();
        HEAP64[(((buf)+(40))>>3)] = BigInt(Math.floor(atime / 1000));
        HEAPU32[(((buf)+(48))>>2)] = (atime % 1000) * 1000 * 1000;
        HEAP64[(((buf)+(56))>>3)] = BigInt(Math.floor(mtime / 1000));
        HEAPU32[(((buf)+(64))>>2)] = (mtime % 1000) * 1000 * 1000;
        HEAP64[(((buf)+(72))>>3)] = BigInt(Math.floor(ctime / 1000));
        HEAPU32[(((buf)+(80))>>2)] = (ctime % 1000) * 1000 * 1000;
        HEAP64[(((buf)+(88))>>3)] = BigInt(stat.ino);
        return 0;
      },
  writeStatFs(buf, stats) {
        HEAPU32[(((buf)+(4))>>2)] = stats.bsize;
        HEAPU32[(((buf)+(60))>>2)] = stats.bsize;
        HEAP64[(((buf)+(8))>>3)] = BigInt(stats.blocks);
        HEAP64[(((buf)+(16))>>3)] = BigInt(stats.bfree);
        HEAP64[(((buf)+(24))>>3)] = BigInt(stats.bavail);
        HEAP64[(((buf)+(32))>>3)] = BigInt(stats.files);
        HEAP64[(((buf)+(40))>>3)] = BigInt(stats.ffree);
        HEAPU32[(((buf)+(48))>>2)] = stats.fsid;
        HEAPU32[(((buf)+(64))>>2)] = stats.flags;  // ST_NOSUID
        HEAPU32[(((buf)+(56))>>2)] = stats.namelen;
      },
  doMsync(addr, stream, len, flags, offset) {
        if (!FS.isFile(stream.node.mode)) {
          throw new FS.ErrnoError(43);
        }
        if (flags & 2) {
          // MAP_PRIVATE calls need not to be synced back to underlying fs
          return 0;
        }
        var buffer = HEAPU8.slice(addr, addr + len);
        FS.msync(stream, buffer, offset, len, flags);
      },
  getStreamFromFD(fd) {
        var stream = FS.getStreamChecked(fd);
        return stream;
      },
  varargs:undefined,
  getStr(ptr) {
        var ret = UTF8ToString(ptr);
        return ret;
      },
  };
  function ___syscall_faccessat(dirfd, path, amode, flags) {
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      if (amode & ~7) {
        // need a valid mode
        return -28;
      }
      var lookup = FS.lookupPath(path, { follow: true });
      var node = lookup.node;
      if (!node) {
        return -44;
      }
      var perms = '';
      if (amode & 4) perms += 'r';
      if (amode & 2) perms += 'w';
      if (amode & 1) perms += 'x';
      if (perms /* otherwise, they've just passed F_OK */ && FS.nodePermissions(node, perms)) {
        return -2;
      }
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  var syscallGetVarargI = () => {
      // the `+` prepended here is necessary to convince the JSCompiler that varargs is indeed a number.
      var ret = HEAP32[((+SYSCALLS.varargs)>>2)];
      SYSCALLS.varargs += 4;
      return ret;
    };
  var syscallGetVarargP = syscallGetVarargI;
  
  
  function ___syscall_fcntl64(fd, cmd, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      switch (cmd) {
        case 0: {
          var arg = syscallGetVarargI();
          if (arg < 0) {
            return -28;
          }
          while (FS.streams[arg]) {
            arg++;
          }
          var newStream;
          newStream = FS.dupStream(stream, arg);
          return newStream.fd;
        }
        case 1:
        case 2:
          return 0;  // FD_CLOEXEC makes no sense for a single process.
        case 3:
          return stream.flags;
        case 4: {
          var arg = syscallGetVarargI();
          var mask = 289792;
          stream.flags = (stream.flags & ~mask) | (arg & mask);
          return 0;
        }
        case 12: {
          var arg = syscallGetVarargP();
          var offset = 0;
          // We're always unlocked.
          HEAP16[(((arg)+(offset))>>1)] = 2;
          return 0;
        }
        case 13:
        case 14:
          // Pretend that the locking is successful. These are process-level locks,
          // and Emscripten programs are a single process. If we supported linking a
          // filesystem between programs, we'd need to do more here.
          // See https://github.com/emscripten-core/emscripten/issues/23697
          return 0;
      }
      return -28;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  function ___syscall_fstat64(fd, buf) {
  try {
  
      return SYSCALLS.writeStat(buf, FS.fstat(fd));
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  
  var stringToUTF8 = (str, outPtr, maxBytesToWrite) => {
      return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
    };
  function ___syscall_getcwd(buf, size) {
  try {
  
      if (size === 0) return -28;
      var cwd = FS.cwd();
      var cwdLengthInBytes = lengthBytesUTF8(cwd) + 1;
      if (size < cwdLengthInBytes) return -68;
      stringToUTF8(cwd, buf, size);
      return cwdLengthInBytes;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  
  function ___syscall_getdents64(fd, dirp, count) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd)
      stream.getdents ||= FS.readdir(stream.path);
  
      var struct_size = 280;
      var pos = 0;
      var off = FS.llseek(stream, 0, 1);
  
      var startIdx = Math.floor(off / struct_size);
      var endIdx = Math.min(stream.getdents.length, startIdx + Math.floor(count/struct_size))
      for (var idx = startIdx; idx < endIdx; idx++) {
        var id;
        var type;
        var name = stream.getdents[idx];
        if (name === '.') {
          id = stream.node.id;
          type = 4;
        }
        else if (name === '..') {
          var lookup = FS.lookupPath(stream.path, { parent: true });
          id = lookup.node.id;
          type = 4;
        }
        else {
          var child;
          try {
            child = FS.lookupNode(stream.node, name);
          } catch (e) {
            // If the entry is not a directory, file, or symlink, nodefs
            // lookupNode will raise EINVAL. Skip these and continue.
            if (e?.errno === 28) {
              continue;
            }
            throw e;
          }
          id = child.id;
          type = FS.isChrdev(child.mode) ? 2 : // character device.
                 FS.isDir(child.mode) ? 4 :    // directory
                 FS.isLink(child.mode) ? 10 :   // symbolic link.
                 8;                            // regular file.
        }
        HEAP64[((dirp + pos)>>3)] = BigInt(id);
        HEAP64[(((dirp + pos)+(8))>>3)] = BigInt((idx + 1) * struct_size);
        HEAP16[(((dirp + pos)+(16))>>1)] = 280;
        HEAP8[(dirp + pos)+(18)] = type;
        stringToUTF8(name, dirp + pos + 19, 256);
        pos += struct_size;
      }
      FS.llseek(stream, idx * struct_size, 0);
      return pos;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  
  function ___syscall_ioctl(fd, op, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      switch (op) {
        case 21509: {
          if (!stream.tty) return -59;
          return 0;
        }
        case 21505: {
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tcgets) {
            var termios = stream.tty.ops.ioctl_tcgets(stream);
            var argp = syscallGetVarargP();
            HEAP32[((argp)>>2)] = termios.c_iflag || 0;
            HEAP32[(((argp)+(4))>>2)] = termios.c_oflag || 0;
            HEAP32[(((argp)+(8))>>2)] = termios.c_cflag || 0;
            HEAP32[(((argp)+(12))>>2)] = termios.c_lflag || 0;
            for (var i = 0; i < 32; i++) {
              HEAP8[(argp + i)+(17)] = termios.c_cc[i] || 0;
            }
            return 0;
          }
          return 0;
        }
        case 21510:
        case 21511:
        case 21512: {
          if (!stream.tty) return -59;
          return 0; // no-op, not actually adjusting terminal settings
        }
        case 21506:
        case 21507:
        case 21508: {
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tcsets) {
            var argp = syscallGetVarargP();
            var c_iflag = HEAP32[((argp)>>2)];
            var c_oflag = HEAP32[(((argp)+(4))>>2)];
            var c_cflag = HEAP32[(((argp)+(8))>>2)];
            var c_lflag = HEAP32[(((argp)+(12))>>2)];
            var c_cc = []
            for (var i = 0; i < 32; i++) {
              c_cc.push(HEAP8[(argp + i)+(17)]);
            }
            return stream.tty.ops.ioctl_tcsets(stream.tty, op, { c_iflag, c_oflag, c_cflag, c_lflag, c_cc });
          }
          return 0; // no-op, not actually adjusting terminal settings
        }
        case 21519: {
          if (!stream.tty) return -59;
          var argp = syscallGetVarargP();
          HEAP32[((argp)>>2)] = 0;
          return 0;
        }
        case 21520: {
          if (!stream.tty) return -59;
          return -28; // not supported
        }
        case 21537:
        case 21531: {
          var argp = syscallGetVarargP();
          return FS.ioctl(stream, op, argp);
        }
        case 21523: {
          // TODO: in theory we should write to the winsize struct that gets
          // passed in, but for now musl doesn't read anything on it
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tiocgwinsz) {
            var winsize = stream.tty.ops.ioctl_tiocgwinsz(stream.tty);
            var argp = syscallGetVarargP();
            HEAP16[((argp)>>1)] = winsize[0];
            HEAP16[(((argp)+(2))>>1)] = winsize[1];
          }
          return 0;
        }
        case 21524: {
          // TODO: technically, this ioctl call should change the window size.
          // but, since emscripten doesn't have any concept of a terminal window
          // yet, we'll just silently throw it away as we do TIOCGWINSZ
          if (!stream.tty) return -59;
          return 0;
        }
        case 21515: {
          if (!stream.tty) return -59;
          return 0;
        }
        default: return -28; // not supported
      }
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  function ___syscall_lstat64(path, buf) {
  try {
  
      path = SYSCALLS.getStr(path);
      return SYSCALLS.writeStat(buf, FS.lstat(path));
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  function ___syscall_newfstatat(dirfd, path, buf, flags) {
  try {
  
      path = SYSCALLS.getStr(path);
      var nofollow = flags & 256;
      var allowEmpty = flags & 4096;
      flags = flags & (~6400);
      path = SYSCALLS.calculateAt(dirfd, path, allowEmpty);
      return SYSCALLS.writeStat(buf, nofollow ? FS.lstat(path) : FS.stat(path));
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  
  function ___syscall_openat(dirfd, path, flags, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      var mode = varargs ? syscallGetVarargI() : 0;
      if (flags & 64) {
        mode &= ~SYSCALLS.currentUmask;
      }
      return FS.open(path, flags, mode).fd;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  
  
  function ___syscall_readlinkat(dirfd, path, buf, bufsize) {
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      if (bufsize <= 0) return -28;
      var ret = FS.readlink(path);
  
      var len = Math.min(bufsize, lengthBytesUTF8(ret));
      var endChar = HEAP8[buf+len];
      stringToUTF8(ret, buf, bufsize+1);
      // readlink is one of the rare functions that write out a C string, but does never append a null to the output buffer(!)
      // stringToUTF8() always appends a null byte, so restore the character under the null byte after the write.
      HEAP8[buf+len] = endChar;
      return len;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  function ___syscall_stat64(path, buf) {
  try {
  
      path = SYSCALLS.getStr(path);
      return SYSCALLS.writeStat(buf, FS.stat(path));
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  function ___syscall_unlinkat(dirfd, path, flags) {
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      if (!flags) {
        FS.unlink(path);
      } else if (flags === 512) {
        FS.rmdir(path);
      } else {
        return -28;
      }
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }
  

  var __abort_js = () =>
      abort('');

  var runtimeKeepaliveCounter = 0;
  var __emscripten_runtime_keepalive_clear = () => {
      noExitRuntime = false;
      runtimeKeepaliveCounter = 0;
    };

  var INT53_MAX = 9007199254740992;
  
  var INT53_MIN = -9007199254740992;
  var bigintToI53Checked = (num) => (num < INT53_MIN || num > INT53_MAX) ? NaN : Number(num);
  function __gmtime_js(time, tmPtr) {
    time = bigintToI53Checked(time);
  
  
      var date = new Date(time * 1000);
      HEAP32[((tmPtr)>>2)] = date.getUTCSeconds();
      HEAP32[(((tmPtr)+(4))>>2)] = date.getUTCMinutes();
      HEAP32[(((tmPtr)+(8))>>2)] = date.getUTCHours();
      HEAP32[(((tmPtr)+(12))>>2)] = date.getUTCDate();
      HEAP32[(((tmPtr)+(16))>>2)] = date.getUTCMonth();
      HEAP32[(((tmPtr)+(20))>>2)] = date.getUTCFullYear()-1900;
      HEAP32[(((tmPtr)+(24))>>2)] = date.getUTCDay();
      var start = Date.UTC(date.getUTCFullYear(), 0, 1, 0, 0, 0, 0);
      var yday = ((date.getTime() - start) / (1000 * 60 * 60 * 24))|0;
      HEAP32[(((tmPtr)+(28))>>2)] = yday;
    ;
  }

  var isLeapYear = (year) => year%4 === 0 && (year%100 !== 0 || year%400 === 0);
  
  var MONTH_DAYS_LEAP_CUMULATIVE = [0,31,60,91,121,152,182,213,244,274,305,335];
  
  var MONTH_DAYS_REGULAR_CUMULATIVE = [0,31,59,90,120,151,181,212,243,273,304,334];
  var ydayFromDate = (date) => {
      var leap = isLeapYear(date.getFullYear());
      var monthDaysCumulative = (leap ? MONTH_DAYS_LEAP_CUMULATIVE : MONTH_DAYS_REGULAR_CUMULATIVE);
      var yday = monthDaysCumulative[date.getMonth()] + date.getDate() - 1; // -1 since it's days since Jan 1
  
      return yday;
    };
  
  function __localtime_js(time, tmPtr) {
    time = bigintToI53Checked(time);
  
  
      var date = new Date(time*1000);
      HEAP32[((tmPtr)>>2)] = date.getSeconds();
      HEAP32[(((tmPtr)+(4))>>2)] = date.getMinutes();
      HEAP32[(((tmPtr)+(8))>>2)] = date.getHours();
      HEAP32[(((tmPtr)+(12))>>2)] = date.getDate();
      HEAP32[(((tmPtr)+(16))>>2)] = date.getMonth();
      HEAP32[(((tmPtr)+(20))>>2)] = date.getFullYear()-1900;
      HEAP32[(((tmPtr)+(24))>>2)] = date.getDay();
  
      var yday = ydayFromDate(date)|0;
      HEAP32[(((tmPtr)+(28))>>2)] = yday;
      HEAP32[(((tmPtr)+(36))>>2)] = -(date.getTimezoneOffset() * 60);
  
      // Attention: DST is in December in South, and some regions don't have DST at all.
      var start = new Date(date.getFullYear(), 0, 1);
      var summerOffset = new Date(date.getFullYear(), 6, 1).getTimezoneOffset();
      var winterOffset = start.getTimezoneOffset();
      var dst = (summerOffset != winterOffset && date.getTimezoneOffset() == Math.min(winterOffset, summerOffset))|0;
      HEAP32[(((tmPtr)+(32))>>2)] = dst;
    ;
  }

  
  
  
  
  
  function __mmap_js(len, prot, flags, fd, offset, allocated, addr) {
    offset = bigintToI53Checked(offset);
  
  
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      var res = FS.mmap(stream, len, offset, prot, flags);
      var ptr = res.ptr;
      HEAP32[((allocated)>>2)] = res.allocated;
      HEAPU32[((addr)>>2)] = ptr;
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  ;
  }

  
  function __munmap_js(addr, len, prot, flags, fd, offset) {
    offset = bigintToI53Checked(offset);
  
  
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      if (prot & 2) {
        SYSCALLS.doMsync(addr, stream, len, flags, offset);
      }
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  ;
  }

  var __tzset_js = (timezone, daylight, std_name, dst_name) => {
      // TODO: Use (malleable) environment variables instead of system settings.
      var currentYear = new Date().getFullYear();
      var winter = new Date(currentYear, 0, 1);
      var summer = new Date(currentYear, 6, 1);
      var winterOffset = winter.getTimezoneOffset();
      var summerOffset = summer.getTimezoneOffset();
  
      // Local standard timezone offset. Local standard time is not adjusted for
      // daylight savings.  This code uses the fact that getTimezoneOffset returns
      // a greater value during Standard Time versus Daylight Saving Time (DST).
      // Thus it determines the expected output during Standard Time, and it
      // compares whether the output of the given date the same (Standard) or less
      // (DST).
      var stdTimezoneOffset = Math.max(winterOffset, summerOffset);
  
      // timezone is specified as seconds west of UTC ("The external variable
      // `timezone` shall be set to the difference, in seconds, between
      // Coordinated Universal Time (UTC) and local standard time."), the same
      // as returned by stdTimezoneOffset.
      // See http://pubs.opengroup.org/onlinepubs/009695399/functions/tzset.html
      HEAPU32[((timezone)>>2)] = stdTimezoneOffset * 60;
  
      HEAP32[((daylight)>>2)] = Number(winterOffset != summerOffset);
  
      var extractZone = (timezoneOffset) => {
        // Why inverse sign?
        // Read here https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getTimezoneOffset
        var sign = timezoneOffset >= 0 ? "-" : "+";
  
        var absOffset = Math.abs(timezoneOffset)
        var hours = String(Math.floor(absOffset / 60)).padStart(2, "0");
        var minutes = String(absOffset % 60).padStart(2, "0");
  
        return `UTC${sign}${hours}${minutes}`;
      }
  
      var winterName = extractZone(winterOffset);
      var summerName = extractZone(summerOffset);
      if (summerOffset < winterOffset) {
        // Northern hemisphere
        stringToUTF8(winterName, std_name, 17);
        stringToUTF8(summerName, dst_name, 17);
      } else {
        stringToUTF8(winterName, dst_name, 17);
        stringToUTF8(summerName, std_name, 17);
      }
    };

  var _emscripten_date_now = () => Date.now();

  var getHeapMax = () =>
      // Stay one Wasm page short of 4GB: while e.g. Chrome is able to allocate
      // full 4GB Wasm memories, the size will wrap back to 0 bytes in Wasm side
      // for any code that deals with heap sizes, which would require special
      // casing all heap size related code to treat 0 specially.
      2147483648;
  var _emscripten_get_heap_max = () => getHeapMax();

  
  
  var growMemory = (size) => {
      var oldHeapSize = wasmMemory.buffer.byteLength;
      var pages = ((size - oldHeapSize + 65535) / 65536) | 0;
      try {
        // round size grow request up to wasm page size (fixed 64KB per spec)
        wasmMemory.grow(pages); // .grow() takes a delta compared to the previous size
        updateMemoryViews();
        Module['onMemoryGrowth']?.(wasmMemory.buffer.byteLength);
        return 1 /*success*/;
      } catch(e) {
      }
      // implicit 0 return to save code size (caller will cast "undefined" into 0
      // anyhow)
    };
  var _emscripten_resize_heap = (requestedSize) => {
      var oldSize = HEAPU8.length;
      // With CAN_ADDRESS_2GB or MEMORY64, pointers are already unsigned.
      requestedSize >>>= 0;
      // With multithreaded builds, races can happen (another thread might increase the size
      // in between), so return a failure, and let the caller retry.
  
      // Memory resize rules:
      // 1.  Always increase heap size to at least the requested size, rounded up
      //     to next page multiple.
      // 2a. If MEMORY_GROWTH_LINEAR_STEP == -1, excessively resize the heap
      //     geometrically: increase the heap size according to
      //     MEMORY_GROWTH_GEOMETRIC_STEP factor (default +20%), At most
      //     overreserve by MEMORY_GROWTH_GEOMETRIC_CAP bytes (default 96MB).
      // 2b. If MEMORY_GROWTH_LINEAR_STEP != -1, excessively resize the heap
      //     linearly: increase the heap size by at least
      //     MEMORY_GROWTH_LINEAR_STEP bytes.
      // 3.  Max size for the heap is capped at 2048MB-WASM_PAGE_SIZE, or by
      //     MAXIMUM_MEMORY, or by ASAN limit, depending on which is smallest
      // 4.  If we were unable to allocate as much memory, it may be due to
      //     over-eager decision to excessively reserve due to (3) above.
      //     Hence if an allocation fails, cut down on the amount of excess
      //     growth, in an attempt to succeed to perform a smaller allocation.
  
      // A limit is set for how much we can grow. We should not exceed that
      // (the wasm binary specifies it, so if we tried, we'd fail anyhow).
      var maxHeapSize = getHeapMax();
      if (requestedSize > maxHeapSize) {
        return false;
      }
  
      // Loop through potential heap size increases. If we attempt a too eager
      // reservation that fails, cut down on the attempted size and reserve a
      // smaller bump instead. (max 3 times, chosen somewhat arbitrarily)
      for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
        var overGrownHeapSize = oldSize * (1 + 0.2 / cutDown); // ensure geometric growth
        // but limit overreserving (default to capping at +96MB overgrowth at most)
        overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296 );
  
        var newSize = Math.min(maxHeapSize, alignMemory(Math.max(requestedSize, overGrownHeapSize), 65536));
  
        var replacement = growMemory(newSize);
        if (replacement) {
  
          return true;
        }
      }
      return false;
    };

  var ENV = {
  };
  
  var getExecutableName = () => thisProgram || './this.program';
  var getEnvStrings = () => {
      if (!getEnvStrings.strings) {
        // Default values.
        var lang = (globalThis.navigator?.language ?? 'C').replace('-', '_') + '.UTF-8';
        var env = {
          'USER': 'web_user',
          'LOGNAME': 'web_user',
          'PATH': '/',
          'PWD': '/',
          'HOME': '/home/web_user',
          'LANG': lang,
          '_': getExecutableName()
        };
        // Apply the user-provided values, if any.
        for (var x in ENV) {
          // x is a key in ENV; if ENV[x] is undefined, that means it was
          // explicitly set to be so. We allow user code to do that to
          // force variables with default values to remain unset.
          if (ENV[x] === undefined) delete env[x];
          else env[x] = ENV[x];
        }
        var strings = [];
        for (var x in env) {
          strings.push(`${x}=${env[x]}`);
        }
        getEnvStrings.strings = strings;
      }
      return getEnvStrings.strings;
    };
  
  var _environ_get = (__environ, environ_buf) => {
      var bufSize = 0;
      var envp = 0;
      for (var string of getEnvStrings()) {
        var ptr = environ_buf + bufSize;
        HEAPU32[(((__environ)+(envp))>>2)] = ptr;
        bufSize += stringToUTF8(string, ptr, Infinity) + 1;
        envp += 4;
      }
      return 0;
    };

  
  var _environ_sizes_get = (penviron_count, penviron_buf_size) => {
      var strings = getEnvStrings();
      HEAPU32[((penviron_count)>>2)] = strings.length;
      var bufSize = 0;
      for (var string of strings) {
        bufSize += lengthBytesUTF8(string) + 1;
      }
      HEAPU32[((penviron_buf_size)>>2)] = bufSize;
      return 0;
    };

  
  var keepRuntimeAlive = () => noExitRuntime || runtimeKeepaliveCounter > 0;
  var _proc_exit = (code) => {
      EXITSTATUS = code;
      if (!keepRuntimeAlive()) {
        Module['onExit']?.(code);
        ABORT = true;
      }
      quit_(code, new ExitStatus(code));
    };
  
  /** @param {boolean|number=} implicit */
  var exitJS = (status, implicit) => {
      EXITSTATUS = status;
  
      if (!keepRuntimeAlive()) {
        exitRuntime();
      }
  
      _proc_exit(status);
    };
  var _exit = exitJS;

  function _fd_close(fd) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      FS.close(stream);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }
  

  function _fd_fdstat_get(fd, pbuf) {
  try {
  
      var rightsBase = 0;
      var rightsInheriting = 0;
      var flags = 0;
      {
        var stream = SYSCALLS.getStreamFromFD(fd);
        // All character devices are terminals (other things a Linux system would
        // assume is a character device, like the mouse, we have special APIs for).
        var type = stream.tty ? 2 :
                   FS.isDir(stream.mode) ? 3 :
                   FS.isLink(stream.mode) ? 7 :
                   4;
      }
      HEAP8[pbuf] = type;
      HEAP16[(((pbuf)+(2))>>1)] = flags;
      HEAP64[(((pbuf)+(8))>>3)] = BigInt(rightsBase);
      HEAP64[(((pbuf)+(16))>>3)] = BigInt(rightsInheriting);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }
  

  /** @param {number=} offset */
  var doReadv = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i = 0; i < iovcnt; i++) {
        var ptr = HEAPU32[((iov)>>2)];
        var len = HEAPU32[(((iov)+(4))>>2)];
        iov += 8;
        var curr = FS.read(stream, HEAP8, ptr, len, offset);
        if (curr < 0) return -1;
        ret += curr;
        if (curr < len) break; // nothing more to read
        if (typeof offset != 'undefined') {
          offset += curr;
        }
      }
      return ret;
    };
  
  function _fd_read(fd, iov, iovcnt, pnum) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      var num = doReadv(stream, iov, iovcnt);
      HEAPU32[((pnum)>>2)] = num;
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }
  

  
  function _fd_seek(fd, offset, whence, newOffset) {
    offset = bigintToI53Checked(offset);
  
  
  try {
  
      if (isNaN(offset)) return 22;
      var stream = SYSCALLS.getStreamFromFD(fd);
      FS.llseek(stream, offset, whence);
      HEAP64[((newOffset)>>3)] = BigInt(stream.position);
      if (stream.getdents && offset === 0 && whence === 0) stream.getdents = null; // reset readdir state
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  ;
  }

  /** @param {number=} offset */
  var doWritev = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i = 0; i < iovcnt; i++) {
        var ptr = HEAPU32[((iov)>>2)];
        var len = HEAPU32[(((iov)+(4))>>2)];
        iov += 8;
        var curr = FS.write(stream, HEAP8, ptr, len, offset);
        if (curr < 0) return -1;
        ret += curr;
        if (curr < len) {
          // No more space to write.
          break;
        }
        if (typeof offset != 'undefined') {
          offset += curr;
        }
      }
      return ret;
    };
  
  function _fd_write(fd, iov, iovcnt, pnum) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      var num = doWritev(stream, iov, iovcnt);
      HEAPU32[((pnum)>>2)] = num;
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }
  



  var handleException = (e) => {
      // Certain exception types we do not treat as errors since they are used for
      // internal control flow.
      // 1. ExitStatus, which is thrown by exit()
      // 2. "unwind", which is thrown by emscripten_unwind_to_js_event_loop() and others
      //    that wish to return to JS event loop.
      if (e instanceof ExitStatus || e == 'unwind') {
        return EXITSTATUS;
      }
      quit_(1, e);
    };

  
  
  var stackAlloc = (sz) => __emscripten_stack_alloc(sz);
  var stringToUTF8OnStack = (str) => {
      var size = lengthBytesUTF8(str) + 1;
      var ret = stackAlloc(size);
      stringToUTF8(str, ret, size);
      return ret;
    };



  var FS_createPath = (...args) => FS.createPath(...args);



  var FS_unlink = (...args) => FS.unlink(...args);

  var FS_createLazyFile = (...args) => FS.createLazyFile(...args);

  var FS_createDevice = (...args) => FS.createDevice(...args);



  FS.createPreloadedFile = FS_createPreloadedFile;
  FS.preloadFile = FS_preloadFile;
  FS.staticInit();;
// End JS library code

// include: postlibrary.js
// This file is included after the automatically-generated JS library code
// but before the wasm module is created.

{

  // Begin ATMODULES hooks
  if (Module['noExitRuntime']) noExitRuntime = Module['noExitRuntime'];
if (Module['preloadPlugins']) preloadPlugins = Module['preloadPlugins'];
if (Module['print']) out = Module['print'];
if (Module['printErr']) err = Module['printErr'];
if (Module['wasmBinary']) wasmBinary = Module['wasmBinary'];
  // End ATMODULES hooks

  if (Module['arguments']) arguments_ = Module['arguments'];
  if (Module['thisProgram']) thisProgram = Module['thisProgram'];

  if (Module['preInit']) {
    if (typeof Module['preInit'] == 'function') Module['preInit'] = [Module['preInit']];
    while (Module['preInit'].length > 0) {
      Module['preInit'].shift()();
    }
  }
}

// Begin runtime exports
  Module['callMain'] = callMain;
  Module['addRunDependency'] = addRunDependency;
  Module['removeRunDependency'] = removeRunDependency;
  Module['FS_preloadFile'] = FS_preloadFile;
  Module['FS_unlink'] = FS_unlink;
  Module['FS_createPath'] = FS_createPath;
  Module['FS_createDevice'] = FS_createDevice;
  Module['FS'] = FS;
  Module['FS_createDataFile'] = FS_createDataFile;
  Module['FS_createLazyFile'] = FS_createLazyFile;
  // End runtime exports
  // Begin JS library exports
  // End JS library exports

// end include: postlibrary.js


// Imports from the Wasm binary.
var __Z5debugR3vecI8cp_token5va_gc8vl_embedE,
  __Z5debugP3vecI8cp_token5va_gc8vl_embedE,
  __Z5debugR9cp_parser,
  __Z5debugP9cp_parser,
  __Z5debugR8cp_token,
  __Z5debugP8cp_token,
  __Z10debug_tree7cp_expr,
  __Z10debug_treeP9tree_node,
  __Z22verify_sequence_pointsP9tree_node,
  __Z5debugR16cp_binding_level,
  __Z5debugP16cp_binding_level,
  __Z12debug_c_treeP9tree_node,
  __Z21debug_print_page_listi,
  __Z17debug_bitmap_fileP8_IO_FILEPK11bitmap_head,
  __Z12debug_bitmapPK11bitmap_head,
  __Z12bitmap_printP8_IO_FILEPK11bitmap_headPKcS5_,
  __Z5debugRK11bitmap_head,
  __Z5debugPK11bitmap_head,
  __Z5debugR8edge_def,
  __Z5debugP8edge_def,
  __Z8debug_bbP15basic_block_def,
  __Z10debug_bb_ni,
  __Z15print_edge_listP8_IO_FILEP9edge_list,
  __Z16verify_edge_listP8_IO_FILEP9edge_list,
  __Z16verify_flow_infov,
  __Z5debugR15basic_block_def,
  __Z5debugP15basic_block_def,
  __Z15debug_flow_infov,
  __Z21verify_loop_structurev,
  __Z17verify_dominators13cdi_direction,
  __Z17verify_insn_chainv,
  __ZN11symtab_node12debug_symtabEv,
  __ZN11symtab_node5debugEv,
  __ZN11symtab_node11verify_baseEv,
  __ZN11symtab_node6verifyEv,
  __ZN11cgraph_node11verify_nodeEv,
  __ZN11symtab_node19verify_symtab_nodesEv,
  __ZN11cgraph_node5debugEv,
  __Z17debug_gimple_stmtP6gimple,
  __ZN11cgraph_node19verify_cgraph_nodesEv,
  __Z18dump_combine_statsP8_IO_FILE,
  __Z10dump_classP9table_elt,
  __Z12debug_regsetP11bitmap_head,
  __Z13df_insn_debugP8rtx_insnbP8_IO_FILE,
  __Z19df_insn_debug_regnoP8rtx_insnP8_IO_FILE,
  __Z14df_regno_debugjP8_IO_FILE,
  __Z12df_ref_debugP8df_ref_dP8_IO_FILE,
  __Z13debug_df_insnP8rtx_insn,
  __Z9debug_rtxPK7rtx_def,
  __Z12debug_df_regP7rtx_def,
  __Z14debug_df_regnoj,
  __Z12debug_df_refP8df_ref_d,
  __Z14debug_df_defnoj,
  __Z14debug_df_usenoj,
  __Z14debug_df_chainP7df_link,
  __Z20debug_dominance_info13cdi_direction,
  __Z20debug_dominance_tree13cdi_directionP15basic_block_def,
  __Z10verify_dieP10die_struct,
  __Z21debug_dwarf_loc_descrP17dw_loc_descr_node,
  __Z15debug_dwarf_dieP10die_struct,
  __Z5debugR10die_struct,
  __Z5debugP10die_struct,
  __Z11debug_dwarfv,
  __Z18debug_generic_stmtP9tree_node,
  __Z11verify_typePK9tree_node,
  __Z18verify_rtl_sharingv,
  __Z14verify_eh_treeP8function,
  __Z13debug_eh_treeP8function,
  __Z28debug_find_var_in_block_treeP9tree_nodeS0_,
  __Z5debugR6gimple,
  __Z5debugP6gimple,
  __Z16debug_gimple_seqP6gimple,
  __Z20verify_gimple_in_seqP6gimple,
  __Z15print_graph_cfgP8_IO_FILEP8function,
  __Z15print_graph_cfgP8_IO_FILEP8functioni,
  __Z18debug_schedule_astP12isl_scheduleP4scop,
  __Z15debug_gmp_valueP12__mpz_struct,
  __Z22debug_iteration_domainP7poly_bb,
  __Z23debug_iteration_domainsP4scop,
  __Z9debug_pdrP7poly_dr,
  __Z10debug_pdrsP7poly_bb,
  __Z16debug_pbb_domainP7poly_bb,
  __Z9debug_pbbP7poly_bb,
  __Z18debug_scop_contextP4scop,
  __Z10debug_scopP4scop,
  __Z17debug_scop_paramsP4scop,
  __Z13debug_isl_setP7isl_set,
  __Z13debug_isl_mapP7isl_map,
  __Z19debug_isl_union_mapP13isl_union_map,
  __Z13debug_isl_affP7isl_aff,
  __Z20debug_isl_constraintP14isl_constraint,
  __Z18debug_isl_scheduleP12isl_schedule,
  __Z13debug_isl_astP12isl_ast_node,
  __Z14debug_scop_pbbP4scopi,
  __Z12dot_all_seseP8_IO_FILER3vecI6sese_l7va_heap6vl_ptrE,
  __Z8dot_seseR6sese_l,
  __Z7dot_cfgv,
  __Z17debug_hsa_operandP11hsa_op_base,
  __Z14debug_hsa_insnP14hsa_insn_basic,
  __Z12debug_hsa_bbP6hsa_bb,
  __Z14debug_hsa_cfunv,
  __Z16debug_hsa_symbolP10hsa_symbol,
  __Z29ipcp_verify_propagated_valuesv,
  __Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueixP9tree_node,
  __Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueix28ipa_polymorphic_call_context,
  __ZNK28ipa_polymorphic_call_context5debugEv,
  __Z20debug_inline_summaryP11cgraph_node,
  __ZN7ipa_icf8sem_item4dumpEv,
  __Z5debugR16ira_allocno_copy,
  __Z5debugP16ira_allocno_copy,
  __Z5debugR11ira_allocno,
  __Z5debugP11ira_allocno,
  __Z5debugR10live_range,
  __Z5debugP10live_range,
  __Z5debugR14lra_live_range,
  __Z5debugP14lra_live_range,
  __Z15debug_oacc_loopP9oacc_loop,
  __Z16debug_omp_regionP10omp_region,
  __Z21debug_all_omp_regionsv,
  __Z20debug_optab_libfuncsv,
  __Z10debug_passv,
  __Z22verify_loop_closed_ssab,
  __Z15dump_propertiesP8_IO_FILEj,
  __Z16debug_propertiesj,
  __Z20verify_gimple_in_cfgP8functionb,
  __Z10verify_ssabb,
  __Z19dump_active_pluginsP8_IO_FILE,
  __Z20debug_active_pluginsv,
  __Z5debugRK7rtx_def,
  __Z5debugPK7rtx_def,
  __Z14debug_rtx_listPK8rtx_insni,
  __Z15debug_rtx_rangePK8rtx_insnS1_,
  __Z14debug_rtx_findPK8rtx_insni,
  __Z15debug_insn_slimPK8rtx_insn,
  __Z14debug_rtl_slimPK8rtx_insnS1_ii,
  __Z13debug_bb_slimP15basic_block_def,
  __Z15debug_bb_n_slimi,
  __Z9debug_rawRK9tree_node,
  __Z9debug_rawPK9tree_node,
  __Z5debugRK9tree_node,
  __Z5debugPK9tree_node,
  __Z13debug_verboseRK9tree_node,
  __Z13debug_verbosePK9tree_node,
  __Z10debug_headRK9tree_node,
  __Z10debug_headPK9tree_node,
  __Z10debug_bodyRK9tree_node,
  __Z10debug_bodyPK9tree_node,
  __Z9debug_rawR3vecIP9tree_node5va_gc8vl_embedE,
  __Z5debugR3vecIP9tree_node5va_gc8vl_embedE,
  __Z5debugP3vecIP9tree_node5va_gc8vl_embedE,
  __Z9debug_rawP3vecIP9tree_node5va_gc8vl_embedE,
  __Z14debug_vec_treeP3vecIP9tree_node5va_gc8vl_embedE,
  __Z16debug_value_dataP10value_data,
  __Z22debug_reload_to_streamP8_IO_FILE,
  __Z12debug_reloadv,
  __Z9debug_rawR17simple_bitmap_def,
  __Z9debug_rawP17simple_bitmap_def,
  __Z12debug_bitmapPK17simple_bitmap_def,
  __Z5debugR17simple_bitmap_def,
  __Z5debugP17simple_bitmap_def,
  __Z10debug_edgePK8edge_def,
  __Z10debug_seseRK6sese_l,
  __Z5debugRK5sreal,
  __Z5debugPK5sreal,
  __Z9debug_rliP20record_layout_info_s,
  __Z9debug_affP8aff_tree,
  __Z15debug_cfg_statsv,
  __Z18debug_generic_exprP9tree_node,
  __Z17verify_histogramsv,
  __Z11verify_seseP15basic_block_defS0_P3vecIS0_7va_heap6vl_ptrE,
  __Z14debug_functionP9tree_nodei,
  __Z5debugR4loop,
  __Z5debugP4loop,
  __Z13debug_verboseR4loop,
  __Z13debug_verboseP4loop,
  __Z11debug_loopsi,
  __Z10debug_loopP4loopi,
  __Z14debug_loop_numji,
  __Z15verify_eh_edgesP6gimple,
  __Z23verify_eh_dispatch_edgeP12geh_dispatch,
  __Z5debugR3vecIP14data_reference7va_heap6vl_ptrE,
  __Z5debugP3vecIP14data_reference7va_heap6vl_ptrE,
  __Z21debug_data_references3vecIP14data_reference7va_heap6vl_ptrE,
  __Z20debug_data_referenceP14data_reference,
  __Z5debugR14data_reference,
  __Z5debugP14data_reference,
  __Z20dump_affine_functionP8_IO_FILE3vecIP9tree_node7va_heap6vl_ptrE,
  __Z22dump_conflict_functionP8_IO_FILEP17conflict_function,
  __Z14dump_subscriptP8_IO_FILEP9subscript,
  __Z22print_direction_vectorP8_IO_FILEPii,
  __Z17print_dir_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi,
  __Z19print_lambda_vectorP8_IO_FILEPii,
  __Z18print_dist_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi,
  __Z29dump_data_dependence_relationP8_IO_FILEP24data_dependence_relation,
  __Z30debug_data_dependence_relationP24data_dependence_relation,
  __Z30dump_data_dependence_relationsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z5debugR3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z5debugP3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z31debug_data_dependence_relations3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z21dump_dist_dir_vectorsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z9dump_ddrsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z10debug_ddrs3vecIP24data_dependence_relation7va_heap6vl_ptrE,
  __Z14debug_variableP9tree_node,
  __Z15debug_dfa_statsv,
  __Z15debug_find_treeP9tree_nodeS0_,
  __Z14debug_decl_setP11bitmap_head,
  __Z16debug_defs_stacki,
  __Z14debug_currdefsv,
  __Z14debug_tree_ssav,
  __Z20debug_tree_ssa_statsv,
  __Z15debug_var_infosv,
  __Z23debug_names_replaced_byP9tree_node,
  __Z16debug_update_ssav,
  __Z16debug_rdg_vertexP5graphi,
  __Z9debug_rdgP5graph,
  __Z7dot_rdgP5graph,
  __Z20debug_rdg_partitions3vecIP9partition7va_heap6vl_ptrE,
  __Z16debug_tree_chainP9tree_node,
  __Z16debug_alias_infov,
  __Z5debugR11pt_solution,
  __Z5debugP11pt_solution,
  __Z24debug_points_to_info_forP9tree_node,
  __Z19debug_lattice_value16ccp_prop_value_t,
  __Z17debug_scope_blockP9tree_nodei,
  __Z18debug_scope_blocksi,
  __Z5debugR8_var_map,
  __Z5debugP8_var_map,
  __Z5debugR16tree_live_info_d,
  __Z5debugP16tree_live_info_d,
  __Z19verify_ssa_operandsP8functionP6gimple,
  __Z16verify_imm_linksP8_IO_FILEP9tree_node,
  __Z20debug_immediate_usesv,
  __Z24debug_immediate_uses_forP9tree_node,
  __Z14debug_pre_exprP10pre_expr_d,
  __Z16debug_bitmap_setP10bitmap_set,
  __Z21debug_bitmap_sets_forP15basic_block_def,
  __Z23debug_value_expressionsj,
  __Z16debug_ops_vector3vecIP13operand_entry7va_heap6vl_ptrE,
  __Z16debug_constraintP10constraint,
  __Z17debug_constraintsv,
  __Z22debug_constraint_graphv,
  __Z22debug_solution_for_varj,
  __Z23debug_sa_points_to_infov,
  __Z13debug_varinfoP13variable_info,
  __Z12debug_varmapv,
  __Z15debug_same_succv,
  __Z13debug_clusterP10bb_cluster,
  __Z9debug_terP8_IO_FILEP15temp_expr_table,
  __Z18verify_jump_threadPP15basic_block_defj,
  __Z24verify_ssaname_freelistsP8function,
  __Z17debug_value_rangeP11value_range,
  __Z22debug_all_value_rangesv,
  __Z17debug_asserts_forP9tree_node,
  __Z17debug_all_assertsv,
  __Z8debug_dvPv,
  __ZN12varpool_node5debugEv,
  __ZN12varpool_node13debug_varpoolEv,
  _main,
  _fflush,
  ___funcs_on_exit,
  _emscripten_builtin_memalign,
  __emscripten_stack_restore,
  __emscripten_stack_alloc,
  _emscripten_stack_get_current,
  memory,
  __indirect_function_table,
  _debug_rtx_count,
  wasmMemory,
  wasmTable;


function assignWasmExports(wasmExports) {
  __Z5debugR3vecI8cp_token5va_gc8vl_embedE = Module['__Z5debugR3vecI8cp_token5va_gc8vl_embedE'] = wasmExports['_Z5debugR3vecI8cp_token5va_gc8vl_embedE'];
  __Z5debugP3vecI8cp_token5va_gc8vl_embedE = Module['__Z5debugP3vecI8cp_token5va_gc8vl_embedE'] = wasmExports['_Z5debugP3vecI8cp_token5va_gc8vl_embedE'];
  __Z5debugR9cp_parser = Module['__Z5debugR9cp_parser'] = wasmExports['_Z5debugR9cp_parser'];
  __Z5debugP9cp_parser = Module['__Z5debugP9cp_parser'] = wasmExports['_Z5debugP9cp_parser'];
  __Z5debugR8cp_token = Module['__Z5debugR8cp_token'] = wasmExports['_Z5debugR8cp_token'];
  __Z5debugP8cp_token = Module['__Z5debugP8cp_token'] = wasmExports['_Z5debugP8cp_token'];
  __Z10debug_tree7cp_expr = Module['__Z10debug_tree7cp_expr'] = wasmExports['_Z10debug_tree7cp_expr'];
  __Z10debug_treeP9tree_node = Module['__Z10debug_treeP9tree_node'] = wasmExports['_Z10debug_treeP9tree_node'];
  __Z22verify_sequence_pointsP9tree_node = Module['__Z22verify_sequence_pointsP9tree_node'] = wasmExports['_Z22verify_sequence_pointsP9tree_node'];
  __Z5debugR16cp_binding_level = Module['__Z5debugR16cp_binding_level'] = wasmExports['_Z5debugR16cp_binding_level'];
  __Z5debugP16cp_binding_level = Module['__Z5debugP16cp_binding_level'] = wasmExports['_Z5debugP16cp_binding_level'];
  __Z12debug_c_treeP9tree_node = Module['__Z12debug_c_treeP9tree_node'] = wasmExports['_Z12debug_c_treeP9tree_node'];
  __Z21debug_print_page_listi = Module['__Z21debug_print_page_listi'] = wasmExports['_Z21debug_print_page_listi'];
  __Z17debug_bitmap_fileP8_IO_FILEPK11bitmap_head = Module['__Z17debug_bitmap_fileP8_IO_FILEPK11bitmap_head'] = wasmExports['_Z17debug_bitmap_fileP8_IO_FILEPK11bitmap_head'];
  __Z12debug_bitmapPK11bitmap_head = Module['__Z12debug_bitmapPK11bitmap_head'] = wasmExports['_Z12debug_bitmapPK11bitmap_head'];
  __Z12bitmap_printP8_IO_FILEPK11bitmap_headPKcS5_ = Module['__Z12bitmap_printP8_IO_FILEPK11bitmap_headPKcS5_'] = wasmExports['_Z12bitmap_printP8_IO_FILEPK11bitmap_headPKcS5_'];
  __Z5debugRK11bitmap_head = Module['__Z5debugRK11bitmap_head'] = wasmExports['_Z5debugRK11bitmap_head'];
  __Z5debugPK11bitmap_head = Module['__Z5debugPK11bitmap_head'] = wasmExports['_Z5debugPK11bitmap_head'];
  __Z5debugR8edge_def = Module['__Z5debugR8edge_def'] = wasmExports['_Z5debugR8edge_def'];
  __Z5debugP8edge_def = Module['__Z5debugP8edge_def'] = wasmExports['_Z5debugP8edge_def'];
  __Z8debug_bbP15basic_block_def = Module['__Z8debug_bbP15basic_block_def'] = wasmExports['_Z8debug_bbP15basic_block_def'];
  __Z10debug_bb_ni = Module['__Z10debug_bb_ni'] = wasmExports['_Z10debug_bb_ni'];
  __Z15print_edge_listP8_IO_FILEP9edge_list = Module['__Z15print_edge_listP8_IO_FILEP9edge_list'] = wasmExports['_Z15print_edge_listP8_IO_FILEP9edge_list'];
  __Z16verify_edge_listP8_IO_FILEP9edge_list = Module['__Z16verify_edge_listP8_IO_FILEP9edge_list'] = wasmExports['_Z16verify_edge_listP8_IO_FILEP9edge_list'];
  __Z16verify_flow_infov = Module['__Z16verify_flow_infov'] = wasmExports['_Z16verify_flow_infov'];
  __Z5debugR15basic_block_def = Module['__Z5debugR15basic_block_def'] = wasmExports['_Z5debugR15basic_block_def'];
  __Z5debugP15basic_block_def = Module['__Z5debugP15basic_block_def'] = wasmExports['_Z5debugP15basic_block_def'];
  __Z15debug_flow_infov = Module['__Z15debug_flow_infov'] = wasmExports['_Z15debug_flow_infov'];
  __Z21verify_loop_structurev = Module['__Z21verify_loop_structurev'] = wasmExports['_Z21verify_loop_structurev'];
  __Z17verify_dominators13cdi_direction = Module['__Z17verify_dominators13cdi_direction'] = wasmExports['_Z17verify_dominators13cdi_direction'];
  __Z17verify_insn_chainv = Module['__Z17verify_insn_chainv'] = wasmExports['_Z17verify_insn_chainv'];
  __ZN11symtab_node12debug_symtabEv = Module['__ZN11symtab_node12debug_symtabEv'] = wasmExports['_ZN11symtab_node12debug_symtabEv'];
  __ZN11symtab_node5debugEv = Module['__ZN11symtab_node5debugEv'] = wasmExports['_ZN11symtab_node5debugEv'];
  __ZN11symtab_node11verify_baseEv = Module['__ZN11symtab_node11verify_baseEv'] = wasmExports['_ZN11symtab_node11verify_baseEv'];
  __ZN11symtab_node6verifyEv = Module['__ZN11symtab_node6verifyEv'] = wasmExports['_ZN11symtab_node6verifyEv'];
  __ZN11cgraph_node11verify_nodeEv = Module['__ZN11cgraph_node11verify_nodeEv'] = wasmExports['_ZN11cgraph_node11verify_nodeEv'];
  __ZN11symtab_node19verify_symtab_nodesEv = Module['__ZN11symtab_node19verify_symtab_nodesEv'] = wasmExports['_ZN11symtab_node19verify_symtab_nodesEv'];
  __ZN11cgraph_node5debugEv = Module['__ZN11cgraph_node5debugEv'] = wasmExports['_ZN11cgraph_node5debugEv'];
  __Z17debug_gimple_stmtP6gimple = Module['__Z17debug_gimple_stmtP6gimple'] = wasmExports['_Z17debug_gimple_stmtP6gimple'];
  __ZN11cgraph_node19verify_cgraph_nodesEv = Module['__ZN11cgraph_node19verify_cgraph_nodesEv'] = wasmExports['_ZN11cgraph_node19verify_cgraph_nodesEv'];
  __Z18dump_combine_statsP8_IO_FILE = Module['__Z18dump_combine_statsP8_IO_FILE'] = wasmExports['_Z18dump_combine_statsP8_IO_FILE'];
  __Z10dump_classP9table_elt = Module['__Z10dump_classP9table_elt'] = wasmExports['_Z10dump_classP9table_elt'];
  __Z12debug_regsetP11bitmap_head = Module['__Z12debug_regsetP11bitmap_head'] = wasmExports['_Z12debug_regsetP11bitmap_head'];
  __Z13df_insn_debugP8rtx_insnbP8_IO_FILE = Module['__Z13df_insn_debugP8rtx_insnbP8_IO_FILE'] = wasmExports['_Z13df_insn_debugP8rtx_insnbP8_IO_FILE'];
  __Z19df_insn_debug_regnoP8rtx_insnP8_IO_FILE = Module['__Z19df_insn_debug_regnoP8rtx_insnP8_IO_FILE'] = wasmExports['_Z19df_insn_debug_regnoP8rtx_insnP8_IO_FILE'];
  __Z14df_regno_debugjP8_IO_FILE = Module['__Z14df_regno_debugjP8_IO_FILE'] = wasmExports['_Z14df_regno_debugjP8_IO_FILE'];
  __Z12df_ref_debugP8df_ref_dP8_IO_FILE = Module['__Z12df_ref_debugP8df_ref_dP8_IO_FILE'] = wasmExports['_Z12df_ref_debugP8df_ref_dP8_IO_FILE'];
  __Z13debug_df_insnP8rtx_insn = Module['__Z13debug_df_insnP8rtx_insn'] = wasmExports['_Z13debug_df_insnP8rtx_insn'];
  __Z9debug_rtxPK7rtx_def = Module['__Z9debug_rtxPK7rtx_def'] = wasmExports['_Z9debug_rtxPK7rtx_def'];
  __Z12debug_df_regP7rtx_def = Module['__Z12debug_df_regP7rtx_def'] = wasmExports['_Z12debug_df_regP7rtx_def'];
  __Z14debug_df_regnoj = Module['__Z14debug_df_regnoj'] = wasmExports['_Z14debug_df_regnoj'];
  __Z12debug_df_refP8df_ref_d = Module['__Z12debug_df_refP8df_ref_d'] = wasmExports['_Z12debug_df_refP8df_ref_d'];
  __Z14debug_df_defnoj = Module['__Z14debug_df_defnoj'] = wasmExports['_Z14debug_df_defnoj'];
  __Z14debug_df_usenoj = Module['__Z14debug_df_usenoj'] = wasmExports['_Z14debug_df_usenoj'];
  __Z14debug_df_chainP7df_link = Module['__Z14debug_df_chainP7df_link'] = wasmExports['_Z14debug_df_chainP7df_link'];
  __Z20debug_dominance_info13cdi_direction = Module['__Z20debug_dominance_info13cdi_direction'] = wasmExports['_Z20debug_dominance_info13cdi_direction'];
  __Z20debug_dominance_tree13cdi_directionP15basic_block_def = Module['__Z20debug_dominance_tree13cdi_directionP15basic_block_def'] = wasmExports['_Z20debug_dominance_tree13cdi_directionP15basic_block_def'];
  __Z10verify_dieP10die_struct = Module['__Z10verify_dieP10die_struct'] = wasmExports['_Z10verify_dieP10die_struct'];
  __Z21debug_dwarf_loc_descrP17dw_loc_descr_node = Module['__Z21debug_dwarf_loc_descrP17dw_loc_descr_node'] = wasmExports['_Z21debug_dwarf_loc_descrP17dw_loc_descr_node'];
  __Z15debug_dwarf_dieP10die_struct = Module['__Z15debug_dwarf_dieP10die_struct'] = wasmExports['_Z15debug_dwarf_dieP10die_struct'];
  __Z5debugR10die_struct = Module['__Z5debugR10die_struct'] = wasmExports['_Z5debugR10die_struct'];
  __Z5debugP10die_struct = Module['__Z5debugP10die_struct'] = wasmExports['_Z5debugP10die_struct'];
  __Z11debug_dwarfv = Module['__Z11debug_dwarfv'] = wasmExports['_Z11debug_dwarfv'];
  __Z18debug_generic_stmtP9tree_node = Module['__Z18debug_generic_stmtP9tree_node'] = wasmExports['_Z18debug_generic_stmtP9tree_node'];
  __Z11verify_typePK9tree_node = Module['__Z11verify_typePK9tree_node'] = wasmExports['_Z11verify_typePK9tree_node'];
  __Z18verify_rtl_sharingv = Module['__Z18verify_rtl_sharingv'] = wasmExports['_Z18verify_rtl_sharingv'];
  __Z14verify_eh_treeP8function = Module['__Z14verify_eh_treeP8function'] = wasmExports['_Z14verify_eh_treeP8function'];
  __Z13debug_eh_treeP8function = Module['__Z13debug_eh_treeP8function'] = wasmExports['_Z13debug_eh_treeP8function'];
  __Z28debug_find_var_in_block_treeP9tree_nodeS0_ = Module['__Z28debug_find_var_in_block_treeP9tree_nodeS0_'] = wasmExports['_Z28debug_find_var_in_block_treeP9tree_nodeS0_'];
  __Z5debugR6gimple = Module['__Z5debugR6gimple'] = wasmExports['_Z5debugR6gimple'];
  __Z5debugP6gimple = Module['__Z5debugP6gimple'] = wasmExports['_Z5debugP6gimple'];
  __Z16debug_gimple_seqP6gimple = Module['__Z16debug_gimple_seqP6gimple'] = wasmExports['_Z16debug_gimple_seqP6gimple'];
  __Z20verify_gimple_in_seqP6gimple = Module['__Z20verify_gimple_in_seqP6gimple'] = wasmExports['_Z20verify_gimple_in_seqP6gimple'];
  __Z15print_graph_cfgP8_IO_FILEP8function = Module['__Z15print_graph_cfgP8_IO_FILEP8function'] = wasmExports['_Z15print_graph_cfgP8_IO_FILEP8function'];
  __Z15print_graph_cfgP8_IO_FILEP8functioni = Module['__Z15print_graph_cfgP8_IO_FILEP8functioni'] = wasmExports['_Z15print_graph_cfgP8_IO_FILEP8functioni'];
  __Z18debug_schedule_astP12isl_scheduleP4scop = Module['__Z18debug_schedule_astP12isl_scheduleP4scop'] = wasmExports['_Z18debug_schedule_astP12isl_scheduleP4scop'];
  __Z15debug_gmp_valueP12__mpz_struct = Module['__Z15debug_gmp_valueP12__mpz_struct'] = wasmExports['_Z15debug_gmp_valueP12__mpz_struct'];
  __Z22debug_iteration_domainP7poly_bb = Module['__Z22debug_iteration_domainP7poly_bb'] = wasmExports['_Z22debug_iteration_domainP7poly_bb'];
  __Z23debug_iteration_domainsP4scop = Module['__Z23debug_iteration_domainsP4scop'] = wasmExports['_Z23debug_iteration_domainsP4scop'];
  __Z9debug_pdrP7poly_dr = Module['__Z9debug_pdrP7poly_dr'] = wasmExports['_Z9debug_pdrP7poly_dr'];
  __Z10debug_pdrsP7poly_bb = Module['__Z10debug_pdrsP7poly_bb'] = wasmExports['_Z10debug_pdrsP7poly_bb'];
  __Z16debug_pbb_domainP7poly_bb = Module['__Z16debug_pbb_domainP7poly_bb'] = wasmExports['_Z16debug_pbb_domainP7poly_bb'];
  __Z9debug_pbbP7poly_bb = Module['__Z9debug_pbbP7poly_bb'] = wasmExports['_Z9debug_pbbP7poly_bb'];
  __Z18debug_scop_contextP4scop = Module['__Z18debug_scop_contextP4scop'] = wasmExports['_Z18debug_scop_contextP4scop'];
  __Z10debug_scopP4scop = Module['__Z10debug_scopP4scop'] = wasmExports['_Z10debug_scopP4scop'];
  __Z17debug_scop_paramsP4scop = Module['__Z17debug_scop_paramsP4scop'] = wasmExports['_Z17debug_scop_paramsP4scop'];
  __Z13debug_isl_setP7isl_set = Module['__Z13debug_isl_setP7isl_set'] = wasmExports['_Z13debug_isl_setP7isl_set'];
  __Z13debug_isl_mapP7isl_map = Module['__Z13debug_isl_mapP7isl_map'] = wasmExports['_Z13debug_isl_mapP7isl_map'];
  __Z19debug_isl_union_mapP13isl_union_map = Module['__Z19debug_isl_union_mapP13isl_union_map'] = wasmExports['_Z19debug_isl_union_mapP13isl_union_map'];
  __Z13debug_isl_affP7isl_aff = Module['__Z13debug_isl_affP7isl_aff'] = wasmExports['_Z13debug_isl_affP7isl_aff'];
  __Z20debug_isl_constraintP14isl_constraint = Module['__Z20debug_isl_constraintP14isl_constraint'] = wasmExports['_Z20debug_isl_constraintP14isl_constraint'];
  __Z18debug_isl_scheduleP12isl_schedule = Module['__Z18debug_isl_scheduleP12isl_schedule'] = wasmExports['_Z18debug_isl_scheduleP12isl_schedule'];
  __Z13debug_isl_astP12isl_ast_node = Module['__Z13debug_isl_astP12isl_ast_node'] = wasmExports['_Z13debug_isl_astP12isl_ast_node'];
  __Z14debug_scop_pbbP4scopi = Module['__Z14debug_scop_pbbP4scopi'] = wasmExports['_Z14debug_scop_pbbP4scopi'];
  __Z12dot_all_seseP8_IO_FILER3vecI6sese_l7va_heap6vl_ptrE = Module['__Z12dot_all_seseP8_IO_FILER3vecI6sese_l7va_heap6vl_ptrE'] = wasmExports['_Z12dot_all_seseP8_IO_FILER3vecI6sese_l7va_heap6vl_ptrE'];
  __Z8dot_seseR6sese_l = Module['__Z8dot_seseR6sese_l'] = wasmExports['_Z8dot_seseR6sese_l'];
  __Z7dot_cfgv = Module['__Z7dot_cfgv'] = wasmExports['_Z7dot_cfgv'];
  __Z17debug_hsa_operandP11hsa_op_base = Module['__Z17debug_hsa_operandP11hsa_op_base'] = wasmExports['_Z17debug_hsa_operandP11hsa_op_base'];
  __Z14debug_hsa_insnP14hsa_insn_basic = Module['__Z14debug_hsa_insnP14hsa_insn_basic'] = wasmExports['_Z14debug_hsa_insnP14hsa_insn_basic'];
  __Z12debug_hsa_bbP6hsa_bb = Module['__Z12debug_hsa_bbP6hsa_bb'] = wasmExports['_Z12debug_hsa_bbP6hsa_bb'];
  __Z14debug_hsa_cfunv = Module['__Z14debug_hsa_cfunv'] = wasmExports['_Z14debug_hsa_cfunv'];
  __Z16debug_hsa_symbolP10hsa_symbol = Module['__Z16debug_hsa_symbolP10hsa_symbol'] = wasmExports['_Z16debug_hsa_symbolP10hsa_symbol'];
  __Z29ipcp_verify_propagated_valuesv = Module['__Z29ipcp_verify_propagated_valuesv'] = wasmExports['_Z29ipcp_verify_propagated_valuesv'];
  __Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueixP9tree_node = Module['__Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueixP9tree_node'] = wasmExports['_Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueixP9tree_node'];
  __Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueix28ipa_polymorphic_call_context = Module['__Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueix28ipa_polymorphic_call_context'] = wasmExports['_Z29ipcp_val_agg_replacement_ok_pP25ipa_agg_replacement_valueix28ipa_polymorphic_call_context'];
  __ZNK28ipa_polymorphic_call_context5debugEv = Module['__ZNK28ipa_polymorphic_call_context5debugEv'] = wasmExports['_ZNK28ipa_polymorphic_call_context5debugEv'];
  __Z20debug_inline_summaryP11cgraph_node = Module['__Z20debug_inline_summaryP11cgraph_node'] = wasmExports['_Z20debug_inline_summaryP11cgraph_node'];
  __ZN7ipa_icf8sem_item4dumpEv = Module['__ZN7ipa_icf8sem_item4dumpEv'] = wasmExports['_ZN7ipa_icf8sem_item4dumpEv'];
  __Z5debugR16ira_allocno_copy = Module['__Z5debugR16ira_allocno_copy'] = wasmExports['_Z5debugR16ira_allocno_copy'];
  __Z5debugP16ira_allocno_copy = Module['__Z5debugP16ira_allocno_copy'] = wasmExports['_Z5debugP16ira_allocno_copy'];
  __Z5debugR11ira_allocno = Module['__Z5debugR11ira_allocno'] = wasmExports['_Z5debugR11ira_allocno'];
  __Z5debugP11ira_allocno = Module['__Z5debugP11ira_allocno'] = wasmExports['_Z5debugP11ira_allocno'];
  __Z5debugR10live_range = Module['__Z5debugR10live_range'] = wasmExports['_Z5debugR10live_range'];
  __Z5debugP10live_range = Module['__Z5debugP10live_range'] = wasmExports['_Z5debugP10live_range'];
  __Z5debugR14lra_live_range = Module['__Z5debugR14lra_live_range'] = wasmExports['_Z5debugR14lra_live_range'];
  __Z5debugP14lra_live_range = Module['__Z5debugP14lra_live_range'] = wasmExports['_Z5debugP14lra_live_range'];
  __Z15debug_oacc_loopP9oacc_loop = Module['__Z15debug_oacc_loopP9oacc_loop'] = wasmExports['_Z15debug_oacc_loopP9oacc_loop'];
  __Z16debug_omp_regionP10omp_region = Module['__Z16debug_omp_regionP10omp_region'] = wasmExports['_Z16debug_omp_regionP10omp_region'];
  __Z21debug_all_omp_regionsv = Module['__Z21debug_all_omp_regionsv'] = wasmExports['_Z21debug_all_omp_regionsv'];
  __Z20debug_optab_libfuncsv = Module['__Z20debug_optab_libfuncsv'] = wasmExports['_Z20debug_optab_libfuncsv'];
  __Z10debug_passv = Module['__Z10debug_passv'] = wasmExports['_Z10debug_passv'];
  __Z22verify_loop_closed_ssab = Module['__Z22verify_loop_closed_ssab'] = wasmExports['_Z22verify_loop_closed_ssab'];
  __Z15dump_propertiesP8_IO_FILEj = Module['__Z15dump_propertiesP8_IO_FILEj'] = wasmExports['_Z15dump_propertiesP8_IO_FILEj'];
  __Z16debug_propertiesj = Module['__Z16debug_propertiesj'] = wasmExports['_Z16debug_propertiesj'];
  __Z20verify_gimple_in_cfgP8functionb = Module['__Z20verify_gimple_in_cfgP8functionb'] = wasmExports['_Z20verify_gimple_in_cfgP8functionb'];
  __Z10verify_ssabb = Module['__Z10verify_ssabb'] = wasmExports['_Z10verify_ssabb'];
  __Z19dump_active_pluginsP8_IO_FILE = Module['__Z19dump_active_pluginsP8_IO_FILE'] = wasmExports['_Z19dump_active_pluginsP8_IO_FILE'];
  __Z20debug_active_pluginsv = Module['__Z20debug_active_pluginsv'] = wasmExports['_Z20debug_active_pluginsv'];
  __Z5debugRK7rtx_def = Module['__Z5debugRK7rtx_def'] = wasmExports['_Z5debugRK7rtx_def'];
  __Z5debugPK7rtx_def = Module['__Z5debugPK7rtx_def'] = wasmExports['_Z5debugPK7rtx_def'];
  __Z14debug_rtx_listPK8rtx_insni = Module['__Z14debug_rtx_listPK8rtx_insni'] = wasmExports['_Z14debug_rtx_listPK8rtx_insni'];
  __Z15debug_rtx_rangePK8rtx_insnS1_ = Module['__Z15debug_rtx_rangePK8rtx_insnS1_'] = wasmExports['_Z15debug_rtx_rangePK8rtx_insnS1_'];
  __Z14debug_rtx_findPK8rtx_insni = Module['__Z14debug_rtx_findPK8rtx_insni'] = wasmExports['_Z14debug_rtx_findPK8rtx_insni'];
  __Z15debug_insn_slimPK8rtx_insn = Module['__Z15debug_insn_slimPK8rtx_insn'] = wasmExports['_Z15debug_insn_slimPK8rtx_insn'];
  __Z14debug_rtl_slimPK8rtx_insnS1_ii = Module['__Z14debug_rtl_slimPK8rtx_insnS1_ii'] = wasmExports['_Z14debug_rtl_slimPK8rtx_insnS1_ii'];
  __Z13debug_bb_slimP15basic_block_def = Module['__Z13debug_bb_slimP15basic_block_def'] = wasmExports['_Z13debug_bb_slimP15basic_block_def'];
  __Z15debug_bb_n_slimi = Module['__Z15debug_bb_n_slimi'] = wasmExports['_Z15debug_bb_n_slimi'];
  __Z9debug_rawRK9tree_node = Module['__Z9debug_rawRK9tree_node'] = wasmExports['_Z9debug_rawRK9tree_node'];
  __Z9debug_rawPK9tree_node = Module['__Z9debug_rawPK9tree_node'] = wasmExports['_Z9debug_rawPK9tree_node'];
  __Z5debugRK9tree_node = Module['__Z5debugRK9tree_node'] = wasmExports['_Z5debugRK9tree_node'];
  __Z5debugPK9tree_node = Module['__Z5debugPK9tree_node'] = wasmExports['_Z5debugPK9tree_node'];
  __Z13debug_verboseRK9tree_node = Module['__Z13debug_verboseRK9tree_node'] = wasmExports['_Z13debug_verboseRK9tree_node'];
  __Z13debug_verbosePK9tree_node = Module['__Z13debug_verbosePK9tree_node'] = wasmExports['_Z13debug_verbosePK9tree_node'];
  __Z10debug_headRK9tree_node = Module['__Z10debug_headRK9tree_node'] = wasmExports['_Z10debug_headRK9tree_node'];
  __Z10debug_headPK9tree_node = Module['__Z10debug_headPK9tree_node'] = wasmExports['_Z10debug_headPK9tree_node'];
  __Z10debug_bodyRK9tree_node = Module['__Z10debug_bodyRK9tree_node'] = wasmExports['_Z10debug_bodyRK9tree_node'];
  __Z10debug_bodyPK9tree_node = Module['__Z10debug_bodyPK9tree_node'] = wasmExports['_Z10debug_bodyPK9tree_node'];
  __Z9debug_rawR3vecIP9tree_node5va_gc8vl_embedE = Module['__Z9debug_rawR3vecIP9tree_node5va_gc8vl_embedE'] = wasmExports['_Z9debug_rawR3vecIP9tree_node5va_gc8vl_embedE'];
  __Z5debugR3vecIP9tree_node5va_gc8vl_embedE = Module['__Z5debugR3vecIP9tree_node5va_gc8vl_embedE'] = wasmExports['_Z5debugR3vecIP9tree_node5va_gc8vl_embedE'];
  __Z5debugP3vecIP9tree_node5va_gc8vl_embedE = Module['__Z5debugP3vecIP9tree_node5va_gc8vl_embedE'] = wasmExports['_Z5debugP3vecIP9tree_node5va_gc8vl_embedE'];
  __Z9debug_rawP3vecIP9tree_node5va_gc8vl_embedE = Module['__Z9debug_rawP3vecIP9tree_node5va_gc8vl_embedE'] = wasmExports['_Z9debug_rawP3vecIP9tree_node5va_gc8vl_embedE'];
  __Z14debug_vec_treeP3vecIP9tree_node5va_gc8vl_embedE = Module['__Z14debug_vec_treeP3vecIP9tree_node5va_gc8vl_embedE'] = wasmExports['_Z14debug_vec_treeP3vecIP9tree_node5va_gc8vl_embedE'];
  __Z16debug_value_dataP10value_data = Module['__Z16debug_value_dataP10value_data'] = wasmExports['_Z16debug_value_dataP10value_data'];
  __Z22debug_reload_to_streamP8_IO_FILE = Module['__Z22debug_reload_to_streamP8_IO_FILE'] = wasmExports['_Z22debug_reload_to_streamP8_IO_FILE'];
  __Z12debug_reloadv = Module['__Z12debug_reloadv'] = wasmExports['_Z12debug_reloadv'];
  __Z9debug_rawR17simple_bitmap_def = Module['__Z9debug_rawR17simple_bitmap_def'] = wasmExports['_Z9debug_rawR17simple_bitmap_def'];
  __Z9debug_rawP17simple_bitmap_def = Module['__Z9debug_rawP17simple_bitmap_def'] = wasmExports['_Z9debug_rawP17simple_bitmap_def'];
  __Z12debug_bitmapPK17simple_bitmap_def = Module['__Z12debug_bitmapPK17simple_bitmap_def'] = wasmExports['_Z12debug_bitmapPK17simple_bitmap_def'];
  __Z5debugR17simple_bitmap_def = Module['__Z5debugR17simple_bitmap_def'] = wasmExports['_Z5debugR17simple_bitmap_def'];
  __Z5debugP17simple_bitmap_def = Module['__Z5debugP17simple_bitmap_def'] = wasmExports['_Z5debugP17simple_bitmap_def'];
  __Z10debug_edgePK8edge_def = Module['__Z10debug_edgePK8edge_def'] = wasmExports['_Z10debug_edgePK8edge_def'];
  __Z10debug_seseRK6sese_l = Module['__Z10debug_seseRK6sese_l'] = wasmExports['_Z10debug_seseRK6sese_l'];
  __Z5debugRK5sreal = Module['__Z5debugRK5sreal'] = wasmExports['_Z5debugRK5sreal'];
  __Z5debugPK5sreal = Module['__Z5debugPK5sreal'] = wasmExports['_Z5debugPK5sreal'];
  __Z9debug_rliP20record_layout_info_s = Module['__Z9debug_rliP20record_layout_info_s'] = wasmExports['_Z9debug_rliP20record_layout_info_s'];
  __Z9debug_affP8aff_tree = Module['__Z9debug_affP8aff_tree'] = wasmExports['_Z9debug_affP8aff_tree'];
  __Z15debug_cfg_statsv = Module['__Z15debug_cfg_statsv'] = wasmExports['_Z15debug_cfg_statsv'];
  __Z18debug_generic_exprP9tree_node = Module['__Z18debug_generic_exprP9tree_node'] = wasmExports['_Z18debug_generic_exprP9tree_node'];
  __Z17verify_histogramsv = Module['__Z17verify_histogramsv'] = wasmExports['_Z17verify_histogramsv'];
  __Z11verify_seseP15basic_block_defS0_P3vecIS0_7va_heap6vl_ptrE = Module['__Z11verify_seseP15basic_block_defS0_P3vecIS0_7va_heap6vl_ptrE'] = wasmExports['_Z11verify_seseP15basic_block_defS0_P3vecIS0_7va_heap6vl_ptrE'];
  __Z14debug_functionP9tree_nodei = Module['__Z14debug_functionP9tree_nodei'] = wasmExports['_Z14debug_functionP9tree_nodei'];
  __Z5debugR4loop = Module['__Z5debugR4loop'] = wasmExports['_Z5debugR4loop'];
  __Z5debugP4loop = Module['__Z5debugP4loop'] = wasmExports['_Z5debugP4loop'];
  __Z13debug_verboseR4loop = Module['__Z13debug_verboseR4loop'] = wasmExports['_Z13debug_verboseR4loop'];
  __Z13debug_verboseP4loop = Module['__Z13debug_verboseP4loop'] = wasmExports['_Z13debug_verboseP4loop'];
  __Z11debug_loopsi = Module['__Z11debug_loopsi'] = wasmExports['_Z11debug_loopsi'];
  __Z10debug_loopP4loopi = Module['__Z10debug_loopP4loopi'] = wasmExports['_Z10debug_loopP4loopi'];
  __Z14debug_loop_numji = Module['__Z14debug_loop_numji'] = wasmExports['_Z14debug_loop_numji'];
  __Z15verify_eh_edgesP6gimple = Module['__Z15verify_eh_edgesP6gimple'] = wasmExports['_Z15verify_eh_edgesP6gimple'];
  __Z23verify_eh_dispatch_edgeP12geh_dispatch = Module['__Z23verify_eh_dispatch_edgeP12geh_dispatch'] = wasmExports['_Z23verify_eh_dispatch_edgeP12geh_dispatch'];
  __Z5debugR3vecIP14data_reference7va_heap6vl_ptrE = Module['__Z5debugR3vecIP14data_reference7va_heap6vl_ptrE'] = wasmExports['_Z5debugR3vecIP14data_reference7va_heap6vl_ptrE'];
  __Z5debugP3vecIP14data_reference7va_heap6vl_ptrE = Module['__Z5debugP3vecIP14data_reference7va_heap6vl_ptrE'] = wasmExports['_Z5debugP3vecIP14data_reference7va_heap6vl_ptrE'];
  __Z21debug_data_references3vecIP14data_reference7va_heap6vl_ptrE = Module['__Z21debug_data_references3vecIP14data_reference7va_heap6vl_ptrE'] = wasmExports['_Z21debug_data_references3vecIP14data_reference7va_heap6vl_ptrE'];
  __Z20debug_data_referenceP14data_reference = Module['__Z20debug_data_referenceP14data_reference'] = wasmExports['_Z20debug_data_referenceP14data_reference'];
  __Z5debugR14data_reference = Module['__Z5debugR14data_reference'] = wasmExports['_Z5debugR14data_reference'];
  __Z5debugP14data_reference = Module['__Z5debugP14data_reference'] = wasmExports['_Z5debugP14data_reference'];
  __Z20dump_affine_functionP8_IO_FILE3vecIP9tree_node7va_heap6vl_ptrE = Module['__Z20dump_affine_functionP8_IO_FILE3vecIP9tree_node7va_heap6vl_ptrE'] = wasmExports['_Z20dump_affine_functionP8_IO_FILE3vecIP9tree_node7va_heap6vl_ptrE'];
  __Z22dump_conflict_functionP8_IO_FILEP17conflict_function = Module['__Z22dump_conflict_functionP8_IO_FILEP17conflict_function'] = wasmExports['_Z22dump_conflict_functionP8_IO_FILEP17conflict_function'];
  __Z14dump_subscriptP8_IO_FILEP9subscript = Module['__Z14dump_subscriptP8_IO_FILEP9subscript'] = wasmExports['_Z14dump_subscriptP8_IO_FILEP9subscript'];
  __Z22print_direction_vectorP8_IO_FILEPii = Module['__Z22print_direction_vectorP8_IO_FILEPii'] = wasmExports['_Z22print_direction_vectorP8_IO_FILEPii'];
  __Z17print_dir_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi = Module['__Z17print_dir_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi'] = wasmExports['_Z17print_dir_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi'];
  __Z19print_lambda_vectorP8_IO_FILEPii = Module['__Z19print_lambda_vectorP8_IO_FILEPii'] = wasmExports['_Z19print_lambda_vectorP8_IO_FILEPii'];
  __Z18print_dist_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi = Module['__Z18print_dist_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi'] = wasmExports['_Z18print_dist_vectorsP8_IO_FILE3vecIPi7va_heap6vl_ptrEi'];
  __Z29dump_data_dependence_relationP8_IO_FILEP24data_dependence_relation = Module['__Z29dump_data_dependence_relationP8_IO_FILEP24data_dependence_relation'] = wasmExports['_Z29dump_data_dependence_relationP8_IO_FILEP24data_dependence_relation'];
  __Z30debug_data_dependence_relationP24data_dependence_relation = Module['__Z30debug_data_dependence_relationP24data_dependence_relation'] = wasmExports['_Z30debug_data_dependence_relationP24data_dependence_relation'];
  __Z30dump_data_dependence_relationsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z30dump_data_dependence_relationsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z30dump_data_dependence_relationsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z5debugR3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z5debugR3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z5debugR3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z5debugP3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z5debugP3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z5debugP3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z31debug_data_dependence_relations3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z31debug_data_dependence_relations3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z31debug_data_dependence_relations3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z21dump_dist_dir_vectorsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z21dump_dist_dir_vectorsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z21dump_dist_dir_vectorsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z9dump_ddrsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z9dump_ddrsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z9dump_ddrsP8_IO_FILE3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z10debug_ddrs3vecIP24data_dependence_relation7va_heap6vl_ptrE = Module['__Z10debug_ddrs3vecIP24data_dependence_relation7va_heap6vl_ptrE'] = wasmExports['_Z10debug_ddrs3vecIP24data_dependence_relation7va_heap6vl_ptrE'];
  __Z14debug_variableP9tree_node = Module['__Z14debug_variableP9tree_node'] = wasmExports['_Z14debug_variableP9tree_node'];
  __Z15debug_dfa_statsv = Module['__Z15debug_dfa_statsv'] = wasmExports['_Z15debug_dfa_statsv'];
  __Z15debug_find_treeP9tree_nodeS0_ = Module['__Z15debug_find_treeP9tree_nodeS0_'] = wasmExports['_Z15debug_find_treeP9tree_nodeS0_'];
  __Z14debug_decl_setP11bitmap_head = Module['__Z14debug_decl_setP11bitmap_head'] = wasmExports['_Z14debug_decl_setP11bitmap_head'];
  __Z16debug_defs_stacki = Module['__Z16debug_defs_stacki'] = wasmExports['_Z16debug_defs_stacki'];
  __Z14debug_currdefsv = Module['__Z14debug_currdefsv'] = wasmExports['_Z14debug_currdefsv'];
  __Z14debug_tree_ssav = Module['__Z14debug_tree_ssav'] = wasmExports['_Z14debug_tree_ssav'];
  __Z20debug_tree_ssa_statsv = Module['__Z20debug_tree_ssa_statsv'] = wasmExports['_Z20debug_tree_ssa_statsv'];
  __Z15debug_var_infosv = Module['__Z15debug_var_infosv'] = wasmExports['_Z15debug_var_infosv'];
  __Z23debug_names_replaced_byP9tree_node = Module['__Z23debug_names_replaced_byP9tree_node'] = wasmExports['_Z23debug_names_replaced_byP9tree_node'];
  __Z16debug_update_ssav = Module['__Z16debug_update_ssav'] = wasmExports['_Z16debug_update_ssav'];
  __Z16debug_rdg_vertexP5graphi = Module['__Z16debug_rdg_vertexP5graphi'] = wasmExports['_Z16debug_rdg_vertexP5graphi'];
  __Z9debug_rdgP5graph = Module['__Z9debug_rdgP5graph'] = wasmExports['_Z9debug_rdgP5graph'];
  __Z7dot_rdgP5graph = Module['__Z7dot_rdgP5graph'] = wasmExports['_Z7dot_rdgP5graph'];
  __Z20debug_rdg_partitions3vecIP9partition7va_heap6vl_ptrE = Module['__Z20debug_rdg_partitions3vecIP9partition7va_heap6vl_ptrE'] = wasmExports['_Z20debug_rdg_partitions3vecIP9partition7va_heap6vl_ptrE'];
  __Z16debug_tree_chainP9tree_node = Module['__Z16debug_tree_chainP9tree_node'] = wasmExports['_Z16debug_tree_chainP9tree_node'];
  __Z16debug_alias_infov = Module['__Z16debug_alias_infov'] = wasmExports['_Z16debug_alias_infov'];
  __Z5debugR11pt_solution = Module['__Z5debugR11pt_solution'] = wasmExports['_Z5debugR11pt_solution'];
  __Z5debugP11pt_solution = Module['__Z5debugP11pt_solution'] = wasmExports['_Z5debugP11pt_solution'];
  __Z24debug_points_to_info_forP9tree_node = Module['__Z24debug_points_to_info_forP9tree_node'] = wasmExports['_Z24debug_points_to_info_forP9tree_node'];
  __Z19debug_lattice_value16ccp_prop_value_t = Module['__Z19debug_lattice_value16ccp_prop_value_t'] = wasmExports['_Z19debug_lattice_value16ccp_prop_value_t'];
  __Z17debug_scope_blockP9tree_nodei = Module['__Z17debug_scope_blockP9tree_nodei'] = wasmExports['_Z17debug_scope_blockP9tree_nodei'];
  __Z18debug_scope_blocksi = Module['__Z18debug_scope_blocksi'] = wasmExports['_Z18debug_scope_blocksi'];
  __Z5debugR8_var_map = Module['__Z5debugR8_var_map'] = wasmExports['_Z5debugR8_var_map'];
  __Z5debugP8_var_map = Module['__Z5debugP8_var_map'] = wasmExports['_Z5debugP8_var_map'];
  __Z5debugR16tree_live_info_d = Module['__Z5debugR16tree_live_info_d'] = wasmExports['_Z5debugR16tree_live_info_d'];
  __Z5debugP16tree_live_info_d = Module['__Z5debugP16tree_live_info_d'] = wasmExports['_Z5debugP16tree_live_info_d'];
  __Z19verify_ssa_operandsP8functionP6gimple = Module['__Z19verify_ssa_operandsP8functionP6gimple'] = wasmExports['_Z19verify_ssa_operandsP8functionP6gimple'];
  __Z16verify_imm_linksP8_IO_FILEP9tree_node = Module['__Z16verify_imm_linksP8_IO_FILEP9tree_node'] = wasmExports['_Z16verify_imm_linksP8_IO_FILEP9tree_node'];
  __Z20debug_immediate_usesv = Module['__Z20debug_immediate_usesv'] = wasmExports['_Z20debug_immediate_usesv'];
  __Z24debug_immediate_uses_forP9tree_node = Module['__Z24debug_immediate_uses_forP9tree_node'] = wasmExports['_Z24debug_immediate_uses_forP9tree_node'];
  __Z14debug_pre_exprP10pre_expr_d = Module['__Z14debug_pre_exprP10pre_expr_d'] = wasmExports['_Z14debug_pre_exprP10pre_expr_d'];
  __Z16debug_bitmap_setP10bitmap_set = Module['__Z16debug_bitmap_setP10bitmap_set'] = wasmExports['_Z16debug_bitmap_setP10bitmap_set'];
  __Z21debug_bitmap_sets_forP15basic_block_def = Module['__Z21debug_bitmap_sets_forP15basic_block_def'] = wasmExports['_Z21debug_bitmap_sets_forP15basic_block_def'];
  __Z23debug_value_expressionsj = Module['__Z23debug_value_expressionsj'] = wasmExports['_Z23debug_value_expressionsj'];
  __Z16debug_ops_vector3vecIP13operand_entry7va_heap6vl_ptrE = Module['__Z16debug_ops_vector3vecIP13operand_entry7va_heap6vl_ptrE'] = wasmExports['_Z16debug_ops_vector3vecIP13operand_entry7va_heap6vl_ptrE'];
  __Z16debug_constraintP10constraint = Module['__Z16debug_constraintP10constraint'] = wasmExports['_Z16debug_constraintP10constraint'];
  __Z17debug_constraintsv = Module['__Z17debug_constraintsv'] = wasmExports['_Z17debug_constraintsv'];
  __Z22debug_constraint_graphv = Module['__Z22debug_constraint_graphv'] = wasmExports['_Z22debug_constraint_graphv'];
  __Z22debug_solution_for_varj = Module['__Z22debug_solution_for_varj'] = wasmExports['_Z22debug_solution_for_varj'];
  __Z23debug_sa_points_to_infov = Module['__Z23debug_sa_points_to_infov'] = wasmExports['_Z23debug_sa_points_to_infov'];
  __Z13debug_varinfoP13variable_info = Module['__Z13debug_varinfoP13variable_info'] = wasmExports['_Z13debug_varinfoP13variable_info'];
  __Z12debug_varmapv = Module['__Z12debug_varmapv'] = wasmExports['_Z12debug_varmapv'];
  __Z15debug_same_succv = Module['__Z15debug_same_succv'] = wasmExports['_Z15debug_same_succv'];
  __Z13debug_clusterP10bb_cluster = Module['__Z13debug_clusterP10bb_cluster'] = wasmExports['_Z13debug_clusterP10bb_cluster'];
  __Z9debug_terP8_IO_FILEP15temp_expr_table = Module['__Z9debug_terP8_IO_FILEP15temp_expr_table'] = wasmExports['_Z9debug_terP8_IO_FILEP15temp_expr_table'];
  __Z18verify_jump_threadPP15basic_block_defj = Module['__Z18verify_jump_threadPP15basic_block_defj'] = wasmExports['_Z18verify_jump_threadPP15basic_block_defj'];
  __Z24verify_ssaname_freelistsP8function = Module['__Z24verify_ssaname_freelistsP8function'] = wasmExports['_Z24verify_ssaname_freelistsP8function'];
  __Z17debug_value_rangeP11value_range = Module['__Z17debug_value_rangeP11value_range'] = wasmExports['_Z17debug_value_rangeP11value_range'];
  __Z22debug_all_value_rangesv = Module['__Z22debug_all_value_rangesv'] = wasmExports['_Z22debug_all_value_rangesv'];
  __Z17debug_asserts_forP9tree_node = Module['__Z17debug_asserts_forP9tree_node'] = wasmExports['_Z17debug_asserts_forP9tree_node'];
  __Z17debug_all_assertsv = Module['__Z17debug_all_assertsv'] = wasmExports['_Z17debug_all_assertsv'];
  __Z8debug_dvPv = Module['__Z8debug_dvPv'] = wasmExports['_Z8debug_dvPv'];
  __ZN12varpool_node5debugEv = Module['__ZN12varpool_node5debugEv'] = wasmExports['_ZN12varpool_node5debugEv'];
  __ZN12varpool_node13debug_varpoolEv = Module['__ZN12varpool_node13debug_varpoolEv'] = wasmExports['_ZN12varpool_node13debug_varpoolEv'];
  _main = Module['_main'] = wasmExports['__main_argc_argv'];
  _fflush = wasmExports['fflush'];
  ___funcs_on_exit = wasmExports['__funcs_on_exit'];
  _emscripten_builtin_memalign = wasmExports['emscripten_builtin_memalign'];
  __emscripten_stack_restore = wasmExports['_emscripten_stack_restore'];
  __emscripten_stack_alloc = wasmExports['_emscripten_stack_alloc'];
  _emscripten_stack_get_current = wasmExports['emscripten_stack_get_current'];
  memory = wasmMemory = wasmExports['memory'];
  __indirect_function_table = wasmTable = wasmExports['__indirect_function_table'];
  _debug_rtx_count = Module['_debug_rtx_count'] = wasmExports['debug_rtx_count'].value;
}

var wasmImports = {
  /** @export */
  _Unwind_Backtrace: __Unwind_Backtrace,
  /** @export */
  _Unwind_GetIPInfo: __Unwind_GetIPInfo,
  /** @export */
  __call_sighandler: ___call_sighandler,
  /** @export */
  __syscall_faccessat: ___syscall_faccessat,
  /** @export */
  __syscall_fcntl64: ___syscall_fcntl64,
  /** @export */
  __syscall_fstat64: ___syscall_fstat64,
  /** @export */
  __syscall_getcwd: ___syscall_getcwd,
  /** @export */
  __syscall_getdents64: ___syscall_getdents64,
  /** @export */
  __syscall_ioctl: ___syscall_ioctl,
  /** @export */
  __syscall_lstat64: ___syscall_lstat64,
  /** @export */
  __syscall_newfstatat: ___syscall_newfstatat,
  /** @export */
  __syscall_openat: ___syscall_openat,
  /** @export */
  __syscall_readlinkat: ___syscall_readlinkat,
  /** @export */
  __syscall_stat64: ___syscall_stat64,
  /** @export */
  __syscall_unlinkat: ___syscall_unlinkat,
  /** @export */
  _abort_js: __abort_js,
  /** @export */
  _emscripten_runtime_keepalive_clear: __emscripten_runtime_keepalive_clear,
  /** @export */
  _gmtime_js: __gmtime_js,
  /** @export */
  _localtime_js: __localtime_js,
  /** @export */
  _mmap_js: __mmap_js,
  /** @export */
  _munmap_js: __munmap_js,
  /** @export */
  _tzset_js: __tzset_js,
  /** @export */
  emscripten_date_now: _emscripten_date_now,
  /** @export */
  emscripten_get_heap_max: _emscripten_get_heap_max,
  /** @export */
  emscripten_resize_heap: _emscripten_resize_heap,
  /** @export */
  environ_get: _environ_get,
  /** @export */
  environ_sizes_get: _environ_sizes_get,
  /** @export */
  exit: _exit,
  /** @export */
  fd_close: _fd_close,
  /** @export */
  fd_fdstat_get: _fd_fdstat_get,
  /** @export */
  fd_read: _fd_read,
  /** @export */
  fd_seek: _fd_seek,
  /** @export */
  fd_write: _fd_write,
  /** @export */
  proc_exit: _proc_exit
};


// include: postamble.js
// === Auto-generated postamble setup entry stuff ===

function callMain(args = []) {

  var entryFunction = _main;

  args.unshift(thisProgram);

  var argc = args.length;
  var argv = stackAlloc((argc + 1) * 4);
  var argv_ptr = argv;
  for (var arg of args) {
    HEAPU32[((argv_ptr)>>2)] = stringToUTF8OnStack(arg);
    argv_ptr += 4;
  }
  HEAPU32[((argv_ptr)>>2)] = 0;

  try {

    var ret = entryFunction(argc, argv);

    // if we're not running an evented main loop, it's time to exit
    exitJS(ret, /* implicit = */ true);
    return ret;
  } catch (e) {
    return handleException(e);
  }
}

function run(args = arguments_) {

  if (runDependencies > 0) {
    dependenciesFulfilled = run;
    return;
  }

  preRun();

  // a preRun added a dependency, run will be called later
  if (runDependencies > 0) {
    dependenciesFulfilled = run;
    return;
  }

  function doRun() {
    // run may have just been called through dependencies being fulfilled just in this very frame,
    // or while the async setStatus time below was happening
    Module['calledRun'] = true;

    if (ABORT) return;

    initRuntime();

    preMain();

    readyPromiseResolve?.(Module);
    Module['onRuntimeInitialized']?.();

    var noInitialRun = Module['noInitialRun'] || true;
    if (!noInitialRun) callMain(args);

    postRun();
  }

  if (Module['setStatus']) {
    Module['setStatus']('Running...');
    setTimeout(() => {
      setTimeout(() => Module['setStatus'](''), 1);
      doRun();
    }, 1);
  } else
  {
    doRun();
  }
}

var wasmExports;

// In modularize mode the generated code is within a factory function so we
// can use await here (since it's not top-level-await).
wasmExports = await (createWasm());

run();

// end include: postamble.js

// include: postamble_modularize.js
// In MODULARIZE mode we wrap the generated code in a factory function
// and return either the Module itself, or a promise of the module.
//
// We assign to the `moduleRtn` global here and configure closure to see
// this as an extern so it won't get minified.

if (runtimeInitialized)  {
  moduleRtn = Module;
} else {
  // Set up the promise that indicates the Module is initialized
  moduleRtn = new Promise((resolve, reject) => {
    readyPromiseResolve = resolve;
    readyPromiseReject = reject;
  });
}

// end include: postamble_modularize.js



  return moduleRtn;
}

// Export using a UMD style export, or ES6 exports if selected
export default Module;
